REFINED NANO V4 — COMPACT EVIDENCE SNAPSHOT

Released model: public/models/refined-nano-v4.onnx
SHA-256: 3772611174d50c181668ed5f4984b65d6e8fbaad6b438a942941ad9901497633
Architecture: 6 -> 16 -> 3, Tanh; 163 scalar parameters, 144 MACs.
Selected checkpoint: training/runs/nano163-refine-20261106/cma/cma-fine-g40.pt

TWO SEPARATE FROZEN COMPARISONS
1. nano163-refine-20261106: 24 development, 96 selection and 256 confirmation
   paired seeds. The retained candidate's six-opponent confirmation mean is
   30.46%, versus 26.62% for unchanged trained163 and 39.80% for Plain Nano447.
   Gain versus unchanged163: +3.84pp, 95% CI +3.04 to +4.61.
2. trained163-vs-quill-plus-20261106: a later fixed-model comparison on 256
   separate paired seeds, with no training or checkpoint selection. Quill Plus
   scores 48.90% against the common field versus 30.02% for Refined Nano.
   Quill wins the direct games 434/46/32 W/L/D. Refined scores better on Attacker.
Different seed sets explain the two Refined Nano field averages. These six-opponent
averages must not be compared directly with the older ten-opponent Quill report.

CONTENTS
The archive preserves the selected ONNX and Torch checkpoint; the exact starting
actor and reference weights; both protocols; complete selection/confirmation
results; all thirteen Quill comparison files with per-rally outcomes; development
metrics and candidate manifests for all ten follow-up arms; training/evaluation
code, frozen source snapshots and amendment records; native/browser verification;
seed and final integrity audits; and the public report. Original repository-relative
paths are retained. SHA256.json hashes every other entry, including this README.

SCOPE AND LIMITATIONS
This is a compact evidence/evaluation snapshot, not a full training-history backup.
Discarded checkpoint weights, optimizer states, large runtime probe arrays, logs,
redundant progress files and older study trajectories are omitted. Candidate and
integrity manifests can reference those omitted files. The original local run
directories retain all search artifacts. Native/browser verification summaries and
the deterministic probe-generation script are included; the generated probe arrays
are not. The earlier depth-study helper code, protocol and starting ONNX are included
for provenance, but that older study is not bundled in full.

Historical release.json is deliberately omitted: its audit_sha256 predates the final
audit's appended report review. Historical protocol/audit/result files are preserved
byte-for-byte. The bundle manifest gives their actual current hashes; it does not
rewrite original provenance claims. This packaging step does not alter any model,
training result, seed set or source snapshot. Earlier reports saying the experiment
made no catalog edits describe the experiment at that time; the later publication
adds the frozen model to the app.

VALIDATION AND REPRODUCTION
Extract into a separate directory, never over the live repository. Python dependency
versions are recorded in training/requirements-lock.txt; Node dependencies are in
package-lock.json. With those dependencies installed, validate the frozen model:
  node --import tsx training/scripts/check_models.ts public/models/refined-nano-v4.onnx

The original comparison files are immutable evidence. To rerun the Quill comparison,
create a new sibling directory under training/runs/, copy compare.py, protocol.json
and models/ from trained163-vs-quill-plus-20261106 into it, and run its compare.py with
the arguments 'run report'. Keep the original included source files at their recorded
paths: the protocol checks their hashes. This recreates matches from frozen models
and serves; it does not need discarded training checkpoints. The original scripts
intentionally refuse to overwrite completed results. Full original checkpoint
selection or training-history replay requires the omitted local search artifacts.

Primary reported intervals use 10,000 whole-paired-seed bootstrap samples. Raw evaluator
rows retain their original 2,000-sample intervals. The confirmation CI correction and
its source hash chain are included. Distinct seed IDs can repeat physical openings,
and the seed audits cover recorded evidence, not unlogged historical training.
