"""Report the preselected model's independent confirmation; no model selection here."""
from pathlib import Path
import json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
P=Path(__file__).resolve().parent
c=json.loads((P/'confirmation.json').read_text());cfg=json.loads((P/'protocol.json').read_text());s=c['summary'];field=cfg['field'];w=c['winner']
labels={'winner':'Selected 163 candidate','start':'Unchanged starting 163','nano447':'Plain Nano 447'};colors=['#287c56','#88958d','#416da0']
values={n:np.array([[v['paired_point_margin']/20+.5 for v in c['results'][n][o]['per_seed']] for o in field]).mean(0) for n in labels}
ix=np.random.default_rng(9601).integers(0,len(values['winner']),(10000,len(values['winner'])))
fig,(a,b)=plt.subplots(2,1,figsize=(11,8),gridspec_kw={'height_ratios':[1,1.6]});fig.patch.set_facecolor('#fafbf8')
for ax in [a,b]:ax.set_facecolor('#fafbf8');ax.spines[['top','right']].set_visible(False);ax.set_axisbelow(True)
for i,n in enumerate(labels):
 mean=100*s['scores'][n];lo,hi=np.quantile(values[n][ix].mean(1),[.025,.975])*100
 a.barh(i,mean,color=colors[i],height=.6);a.errorbar(mean,i,xerr=[[mean-lo],[hi-mean]],fmt='none',ecolor='#28332c',capsize=3);a.text(hi+1,i,f'{mean:.2f}%',va='center')
a.set_yticks(range(3),list(labels.values()));a.invert_yaxis();a.set_xlim(0,100);a.grid(axis='x',alpha=.2);a.set_xlabel('Mean common-field rally score (%)')
x=np.arange(len(field));width=.24
for i,n in enumerate(labels):b.bar(x+(i-1)*width,[100*c['results'][n][o]['score_rate'] for o in field],width,color=colors[i],label=labels[n])
b.set_xticks(x,['Robust Strong','Pacer','Vector Nano','Attacker','Defender','Interceptor']);b.set_ylim(0,100);b.grid(axis='y',alpha=.2);b.set_ylabel('Rally score (%)');b.legend(loc='upper center',bbox_to_anchor=(.5,-.13),ncol=3,frameon=False)
fig.suptitle('163-parameter refinement · independent confirmation',fontsize=17,fontweight='bold',y=.98)
fig.text(.5,.93,'256 paired seeds · 512 five-rally games per opponent · draws count as half a rally win',ha='center',fontsize=10)
fig.text(.5,.025,'Error bars: 95% intervals from resampling whole paired seeds. Models were frozen before the final games.',ha='center',fontsize=9)
fig.subplots_adjust(left=.25,right=.96,top=.87,bottom=.15,hspace=.4);fig.savefig(P/'comparison.png',dpi=160);plt.close(fig)
lines=['163-PARAMETER REFINEMENT — 2026-11-06','',f'Base commit: {cfg["base_commit"]}',
 'Starting model: the previous depth study\'s strongest shallow Tanh 6->16->3 actor; 163 parameters, 144 MACs.',
 'Four 64-generation CMA restart arms: sigma .015/.04/.08 on uniform field, plus .025 emphasizing Robust Strong/Pacer; 20 proposals, 16 training seeds, optimizer restarts every 16 generations.',
 'Four PPO continuations: two learning rates at temperature 1, plus registered lower-temperature .25/.5 follow-up; each 160 actor updates after 8 critic-only warmup updates.',
 'Two matched 24-round warm distillation arms: original data versus 50% mirrored examples, with identical reachable rollouts/minibatches.',
 'Additional PPO and distillation arms were registered from development evidence before independent selection.',
 'No PPO or distillation arm yielded a convincing development improvement. All scheduled checkpoints, including negatives and unchanged controls, remained available for independent selection.',
 'Selected candidate: '+w['name']+'; '+w['method']+'.',
 'Frozen pool: 83 scheduled checkpoint entries, 68 distinct tensor states, including the unchanged control.',
 'Selection: 96 new paired seeds; nonnegative direct margin against start and no script decline over 5 pp; unchanged start always eligible.',
 'Confirmation: 256 separate paired seeds, both sides, five rallies per game; native ONNX evaluation.',
 'Field: '+', '.join(field)+'. Same roster as prior depth comparison; all references re-tested.',
 'Fresh-ID audit: no sampled development/selection/confirmation ID overlap found in about 1.1 million recorded historical seed values, and no known training-range overlap.',
 'Prior depth-study final IDs had no exact recorded matches, but its range overlapped an ancestral training interval. This caveat does not establish exact reuse; fresh IDs do not guarantee new physical states.','', 'Mean rally scores (draw=0.5):']
for n in labels:lines.append(f'  {labels[n]}: {s["scores"][n]*100:.2f}%')
for n,r in s['comparisons'].items():
 lo,hi=r['ci95'];lines.append(f'  Gain vs {labels[n]}: {r["gain"]*100:+.2f}pp, paired-seed 95% CI [{lo*100:+.2f},{hi*100:+.2f}]; strict success: {r["success"]}.')
 lines.append(f'    Direct margin 95% CI: {r["direct_margin_ci95"]}; per-script score changes: {r["script_deltas"]}.')
lines+=['','Selected candidate matchups: game wins / losses / draws; rally score:']
for n,r in c['results']['winner'].items():lines.append(f'  {n}: {r["match_wins"]} / {r["match_losses"]} / {r["match_draws"]}; {r["score_rate"]*100:.2f}%.')
lines+=['','Strict improvement requires positive field-gain and direct-margin intervals, plus no script regression greater than 5 pp.',
 'This is a bounded optimization study against a fixed field, not a global optimum or a general verdict about PPO. Temperature/reward/critic choices could change future results.',
 'All inference remains the same single-hidden-layer dense Tanh actor. Critics, mirror augmentation, teachers and optimizers are training-only.',
 'This experiment made no app/catalog changes. Concurrent main changes added Quill artifacts; all pinned evaluator sources and reference weights still match the original hashes.',
 'All experimental outputs are retained locally under ignored training/runs/.',
 'Native ONNX and browser WASM verification: 4,096 cross-runtime action comparisons per model (candidate, start and 447), zero action differences between runtimes; zero browser console errors. Temporary verification server stopped.',
 'Strict summary intervals use 10,000 whole-seed bootstrap samples. Raw per-matchup rows retain the evaluator\'s original 2,000-sample intervals; see confirmation-ci-amendment.json.',
 'Detailed evidence: protocol.json, source snapshots, seed-audit.json, amendment records, candidate manifests, selection.json, frozen-winner.json, confirmation.json.']
(P/'RESULTS.txt').write_text('\n'.join(lines)+'\n');print('\n'.join(lines[15:26]))
