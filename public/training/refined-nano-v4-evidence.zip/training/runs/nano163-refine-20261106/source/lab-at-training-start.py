"""Refine the strongest retained 163-scalar actor without changing inference rules."""
from pathlib import Path
import sys,json,hashlib,subprocess
ROOT=Path(__file__).resolve().parents[3];OUT=Path(__file__).resolve().parent
PRIOR=ROOT/'training/runs/nano-depth163-20261106'
sys.path[:0]=[str(OUT),str(ROOT/'training/scripts'),str(PRIOR)]
import numpy as np
import torch
from torch import nn
from depth import load_file,export,stats
from policy import OnnxPolicy,load_builtin
from pace_study import CONFIGS,make_policy,run_pair
from population import evaluate_population
from nano_cma import CMA
RULES=CONFIGS['pace13-v9-scaled']
FIELD=['robust-strong-v4','pacer-v4','vector-nano-v4','attack','defend','interceptor']
START=PRIOR/'Nano-163-1hidden-Tanh.onnx'
torch.set_num_threads(1)
def digest(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(name,obj):
 p=OUT/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(obj,indent=2,allow_nan=False)+'\n')
def config():return json.loads((OUT/'protocol.json').read_text())
def load_start():return load_file(START).requires_grad_(True)
def field_score(row):return float(np.mean([row['opponents'][n] for n in FIELD]))
def rivals(extra=False):
 r={n:make_policy(RULES,n) if n in ['attack','defend','interceptor'] else load_builtin(n).requires_grad_(False) for n in FIELD}
 if extra:r.update(start=load_start().requires_grad_(False),nano447=load_builtin('plain-nano-v4').requires_grad_(False))
 return r

def prepare():
 if (OUT/'protocol.json').exists():raise FileExistsError('Already prepared')
 rng=np.random.default_rng(2026110631)
 cfg=dict(base_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),architecture=[6,16,3],parameters=163,macs=144,
  start=str(START.relative_to(ROOT)),start_sha256=digest(START),field=FIELD,
  development_seeds=(rng.choice(1000000,24,replace=False)+4220000000).tolist(),
  selection_seeds=(rng.choice(1000000,96,replace=False)+4240000000).tolist(),
  confirmation_seeds=(rng.choice(1000000,256,replace=False)+4270000000).tolist(),verification_seeds=[4260000101,4260000109],
  cma_training_interval=[2500000000,2510000000],ppo_training_interval=[0,1000000000],
  cma=dict(generations=64,population=20,screen_seeds=16,restart_every=16,eval_every=8,
   arms=[dict(name='fine',sigma=.015,weights=[1/6]*6),dict(name='medium',sigma=.04,weights=[1/6]*6),dict(name='broad',sigma=.08,weights=[1/6]*6),dict(name='learned-focus',sigma=.025,weights=[.25,.25,.125,.125,.125,.125])]),
  ppo=dict(updates=160,envs=128,horizon=128,epochs=3,learning_rates=[.00003,.0001],gamma=1.,gae_lambda=.995,clip=.2,temperature=1.,entropy=.002,anchor_kl=.01,max_grad_norm=.5,target_kl=.02,critic_warmup_updates=8,critic_inputs='six observations + six opponent one-hots + remaining rally time; training only',critic_hidden=[64,64],eval_every=20,rewards='terminal win +1, loss -1, draw 0; no return shaping',opponents='fixed uniform six-opponent field'),
  selection='Freeze all proposals and unchanged start; maximum common-field mean score among candidates with nonnegative direct start margin and no script more than 5pp worse than unchanged start on96 independent paired seeds. Start itself remains eligible.',
  success='Paired-seed mean-field gain lower95%>0, direct start margin lower95%>0, no script point-estimate regression >5pp; compare447 independently with same conditions.',
  confirmation='256 paired seeds, native ONNX, both sides, five rallies/game; fresh common opponent field retained from depth study; 10000 paired-seed bootstrap samples.',
  limitations='Bounded optimization study, not global optimum. Historical final range overlap was identified in prior depth study; this study uses ranges outside known historical training/selection ranges. Different seed IDs can still repeat physical openings.',
  references={str(START.relative_to(ROOT)):digest(START),**{f'public/models/{n}.onnx':digest(ROOT/f'public/models/{n}.onnx') for n in FIELD[:3]+['plain-nano-v4']}},
  sources={str(p.relative_to(ROOT)):digest(p) for p in [Path(__file__),OUT/'population.py',OUT/'nano_cma.py',PRIOR/'depth.py',*sorted((ROOT/'training/scripts').glob('*.py'))]})
 save('protocol.json',cfg)
 for p in sorted((ROOT/'training/scripts').glob('*.py')):
  d=OUT/'source'/p.name;d.parent.mkdir(exist_ok=True);d.write_bytes(p.read_bytes())
 print('Prepared protocol',flush=True)

def search():
 cfg=config();c=cfg['cma'];r=rivals();pool=[]
 if (OUT/'cma').exists():raise FileExistsError('CMA outputs already exist')
 (OUT/'cma').mkdir();template=load_start().state_dict()
 origin=np.concatenate([v.numpy().ravel() for v in template.values()]).astype(float)
 scales=np.concatenate([np.full(v.numel(),max(float(template[k.replace('bias','weight')].square().mean().sqrt()),1/np.sqrt(template[k.replace('bias','weight')].shape[1]))) for k,v in template.items()])
 def decode(vector):
  physical=(origin+scales*vector).astype(np.float32);state={};offset=0
  assert np.isfinite(physical).all()
  for k,v in template.items():state[k]=torch.from_numpy(physical[offset:offset+v.numel()].reshape(v.shape).copy());offset+=v.numel()
  return state
 np.savez_compressed(OUT/'cma/coordinates.npz',origin=origin,scales=scales)
 for index,arm in enumerate(c['arms']):
  incumbent=np.zeros(len(origin));rng=np.random.default_rng(9511+index);history=[];weights=np.array(arm['weights'])
  assert abs(weights.sum()-1)<1e-12
  for generation in range(1,c['generations']+1):
   restart=(generation-1)%c['restart_every']==0
   if restart:optimizer=CMA(incumbent.copy(),arm['sigma'],9501+100*index+generation,c['population'])
   proposals=optimizer.ask();vectors=[*proposals,optimizer.mean.copy(),incumbent.copy()]
   seeds=(rng.choice(10000000,c['screen_seeds'],replace=False)+2500000000).tolist()
   rows,_=evaluate_population([decode(v) for v in vectors],'tanh',seeds,r)
   fitness=np.array([sum(weights[i]*row['opponents'][n] for i,n in enumerate(FIELD)) for row in rows]);optimizer.tell(proposals,-fitness[:c['population']]);chosen=len(vectors)-1
   if fitness.max()>fitness[chosen]+1e-12:chosen=int(fitness.argmax())
   incumbent=vectors[chosen].copy();row=dict(generation=generation,restart=restart,seeds=seeds,chosen=chosen,fitness=fitness.tolist(),optimizer=optimizer.diagnostics())
   if generation%c['eval_every']==0:
    dev,_=evaluate_population([decode(incumbent)],'tanh',cfg['development_seeds'],r);row['development']=dev[0]
    name=f'cma-{arm["name"]}-g{generation}';path=f'cma/{name}.pt';torch.save(decode(incumbent),OUT/path)
    pool.append(dict(name=name,path=path,sha256=digest(OUT/path),hidden=[16],activation='tanh',method=f'CMA restart refinement, sigma {arm["sigma"]}, {arm["name"]}',best=field_score(dev[0])))
    print(name,'dev score',round((field_score(dev[0])+1)*50,2),flush=True)
   else:print('CMA',arm['name'],generation,'training score',round((fitness[chosen]+1)*50,2),flush=True)
   history.append(row);save(f'cma/{arm["name"]}-metrics.json',history)
  save(f'cma/{arm["name"]}-optimizer.json',optimizer.state_dict())
 save('cma/candidates.json',pool)

def select():
 cfg=config();r=rivals(extra=True);pool=[]
 for source in ['cma/candidates.json','ppo/candidates.json']:
  pool+=json.loads((OUT/source).read_text())
 path='unchanged.pt';torch.save(load_start().state_dict(),OUT/path);pool.append(dict(name='unchanged',path=path,sha256=digest(OUT/path),hidden=[16],activation='tanh',method='Unchanged starting weights'))
 for p in pool:
  actual=digest(OUT/p['path'])
  if 'sha256' in p:assert actual==p['sha256']
  p['sha256']=actual
 save('frozen-pool.json',pool);results=[]
 # Bounded batches keep population memory predictable for all retained checkpoints.
 for offset in range(0,len(pool),8):
  group=pool[offset:offset+8]
  rows,_=evaluate_population([torch.load(OUT/p['path'],weights_only=True) for p in group],'tanh',cfg['selection_seeds'],r)
  for p,row in zip(group,rows):results.append(dict(**p,selection=row,field_margin=field_score(row)))
  print('Selected scores for',min(offset+8,len(pool)),'/',len(pool),flush=True)
 baseline=next(p for p in results if p['name']=='unchanged')['selection']['opponents']
 eligible=[p for p in results if p['selection']['opponents']['start']>=0 and all(p['selection']['opponents'][n]>=baseline[n]-.1 for n in ['attack','defend','interceptor'])]
 winner=max(eligible,key=lambda p:p['field_margin']);save('selection.json',dict(winner=winner,candidates=results))
 m=load_start();m.load_state_dict(torch.load(OUT/winner['path'],weights_only=True));export(m,OUT/'winner.onnx',winner['method'])
 save('frozen-winner.json',dict(**winner,onnx_sha256=digest(OUT/'winner.onnx')));print('FROZEN WINNER',winner['name'],'score',50*(1+winner['field_margin']),flush=True)

def confirm():
 cfg=config();winner=json.loads((OUT/'frozen-winner.json').read_text());assert not (OUT/'confirmation.json').exists()
 assert digest(OUT/'winner.onnx')==winner['onnx_sha256']
 for path,want in cfg['references'].items():assert digest(ROOT/path)==want
 paths={'winner':OUT/'winner.onnx','start':START,'nano447':ROOT/'public/models/plain-nano-v4.onnx'}
 subprocess.run(['node','--import','tsx','training/scripts/check_models.ts',*map(str,paths.values())],cwd=ROOT,check=True,stdout=subprocess.DEVNULL)
 native={n:make_policy(RULES,n) if n in ['attack','defend','interceptor'] else OnnxPolicy(ROOT/f'public/models/{n}.onnx') for n in FIELD};results={}
 for name,path in paths.items():
  targets=dict(native);results[name]={}
  if name=='winner':targets.update({n:OnnxPolicy(paths[n]) for n in ['start','nano447']})
  for opponent,policy in targets.items():
   row=run_pair(RULES,OnnxPolicy(path),policy,cfg['confirmation_seeds'])['summary'];results[name][opponent]=row
   print('FINAL',name,opponent,'score',round(row['score_rate']*100,2),'games',row['match_wins'],row['match_losses'],row['match_draws'],flush=True);save('confirmation-progress.json',results)
 values={n:np.array([[p['paired_point_margin']/20+.5 for p in results[n][o]['per_seed']] for o in FIELD]).mean(0) for n in results}
 ix=np.random.default_rng(9601).integers(0,len(values['winner']),(10000,len(values['winner'])));summary=dict(scores={n:float(v.mean()) for n,v in values.items()},comparisons={})
 for n in ['start','nano447']:
  delta=values['winner']-values[n];ci=np.quantile(delta[ix].mean(1),[.025,.975]).tolist();direct=results['winner'][n]['point_margin_ci95'];scripts={o:results['winner'][o]['score_rate']-results[n][o]['score_rate'] for o in ['attack','defend','interceptor']}
  summary['comparisons'][n]=dict(gain=float(delta.mean()),ci95=ci,direct_margin_ci95=direct,script_deltas=scripts,success=ci[0]>0 and direct[0]>0 and min(scripts.values())>=-.05)
 save('confirmation.json',dict(winner=winner,summary=summary,results=results));print('CONFIRMED',summary,flush=True)

if __name__=='__main__':
 for stage in sys.argv[1:]:print('STAGE',stage,flush=True);globals()[stage]()
