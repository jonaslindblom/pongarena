"""Registered low-temperature follow-up; preserve the original PPO implementation."""
from pathlib import Path
import copy,hashlib,json,sys
import numpy as np
import torch
from torch.distributions import Categorical
from lab import OUT,ROOT,config,load_start
from ppo import train_arm
from train_pace import broad_observations


def digest(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def write(path,value):Path(path).write_text(json.dumps(value,indent=2,allow_nan=False)+'\n')


def prepare():
    path=OUT/'ppo/cool-amendment.json'
    if path.exists():raise FileExistsError('Low-temperature follow-up already registered')
    cfg=config();options=copy.deepcopy(cfg['ppo']);options['learning_rates']=[3e-5]
    amendment=dict(
        rationale='Temperature1 continuation usually reduced greedy playing strength; the retained ancestral PPO recipe used temperature.25. Test whether reduced sampling noise better preserves useful greedy trajectories. This decision uses development evidence only.',
        registration_stage='Before either follow-up arm runs and before independent selection or confirmation evaluation',
        unchanged_parent_protocol_sha256=digest(OUT/'protocol.json'),
        unchanged_original_ppo_candidates_sha256=digest(OUT/'ppo/candidates.json'),
        source_sha256={str(p.relative_to(ROOT)):digest(p) for p in [Path(__file__),OUT/'ppo.py',OUT/'lab.py']},
        options=options,
        arms=[dict(name='ppo-temp025',temperature=.25,learning_rate=3e-5),dict(name='ppo-temp050',temperature=.5,learning_rate=3e-5)],
        seed=10301,
        invariant='Temperature is used only for stochastic training distributions; exported actor remains the same six-input,163-scalar,one-hidden-layer Tanh network and greedy argmax.',
        comparison='Same160 actor updates,eight critic warmups,uniform fixed six-opponent field,critic shape,GAE,rewards,optimizer and checkpoint schedule as the original arms.',
        outputs='New arm folders and cool-candidates.json; original eighteen-checkpoint candidates.json remains byte-identical.')
    write(path,amendment)
    print('Registered',path,'sha256',digest(path),flush=True)


def verify():
    amendment=json.loads((OUT/'ppo/cool-amendment.json').read_text());torch.set_num_threads(1);torch.manual_seed(10301)
    actor=load_start();x=torch.from_numpy(broad_observations(np.random.default_rng(10303),4096));rows=[]
    with torch.no_grad():
        logits=actor(x);greedy=logits.argmax(-1)
        for spec in amendment['arms']:
            scaled=logits/spec['temperature'];torch.testing.assert_close(scaled.argmax(-1),greedy,rtol=0,atol=0)
            dist=Categorical(logits=scaled);action=dist.sample();old=dist.log_prob(action)
            torch.testing.assert_close(old,scaled.log_softmax(-1).gather(1,action[:,None]).squeeze(1))
            ratio=(dist.log_prob(action)-old).exp();torch.testing.assert_close(ratio,torch.ones_like(ratio),rtol=0,atol=0)
            assert torch.isfinite(old).all() and torch.isfinite(dist.entropy()).all()
            rows.append(dict(temperature=spec['temperature'],greedy_argmax_matches=4096,stored_log_probability_matches=4096,
                likelihood_ratios_exactly_one=True,finite_log_probabilities=True,mean_sampling_entropy=float(dist.entropy().mean())))
    write(OUT/'ppo/cool-verification.json',dict(passed=True,amendment_sha256=digest(OUT/'ppo/cool-amendment.json'),checks=rows))
    print('Low-temperature numerical checks',json.dumps(rows),flush=True)


def train():
    amendment_path=OUT/'ppo/cool-amendment.json';amendment=json.loads(amendment_path.read_text());base=config()
    assert digest(OUT/'protocol.json')==amendment['unchanged_parent_protocol_sha256']
    assert digest(OUT/'ppo/candidates.json')==amendment['unchanged_original_ppo_candidates_sha256']
    for path,want in amendment['source_sha256'].items():assert digest(ROOT/path)==want,path
    assert json.loads((OUT/'ppo/cool-verification.json').read_text())['passed']
    pool=[]
    for spec in amendment['arms']:
        cfg=copy.deepcopy(base);cfg['ppo']['temperature']=spec['temperature'];cfg['ppo']['seed']=amendment['seed']
        cfg['ppo']['followup_amendment']='ppo/cool-amendment.json';cfg['ppo']['followup_amendment_sha256']=digest(amendment_path)
        items=train_arm(spec['name'],spec['learning_rate'],cfg)
        for item in items:item['method']+=f'; stochastic training temperature={spec["temperature"]}'
        write(OUT/'ppo'/spec['name']/'candidates.json',items)
        (OUT/'ppo'/spec['name']/'followup-source.py').write_bytes(Path(__file__).read_bytes())
        pool.extend(items)
    assert digest(OUT/'ppo/candidates.json')==amendment['unchanged_original_ppo_candidates_sha256']
    write(OUT/'ppo/cool-candidates.json',pool)
    print('Completed low-temperature follow-up:',len(pool),'new candidates; original18 preserved.',flush=True)


if __name__=='__main__':
    for stage in sys.argv[1:]:globals()[stage]()
