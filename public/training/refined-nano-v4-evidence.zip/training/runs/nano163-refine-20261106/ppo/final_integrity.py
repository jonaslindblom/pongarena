"""Read-only integrity audit of PPO/distillation artifacts; no held-out evaluation."""
from pathlib import Path
import ast,hashlib,json,math
import numpy as np
import onnx
from onnx import numpy_helper
import torch

OUT=Path(__file__).resolve().parents[1]
ROOT=OUT.parents[2]


def read(path):return json.loads(Path(path).read_text())
def digest(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def lines(path):return [json.loads(line) for line in Path(path).read_text().splitlines()]
def state(path):
    value=torch.load(path,weights_only=True)
    assert sum(v.numel() for v in value.values())==163 and all(torch.isfinite(v).all() for v in value.values())
    assert [tuple(v.shape) for v in value.values()]==[(16,6),(16,),(3,16),(3,)]
    return value
def state_hash(value):
    h=hashlib.sha256()
    for key,v in value.items():h.update(key.encode());h.update(str(tuple(v.shape)).encode());h.update(v.numpy().tobytes())
    return h.hexdigest()
def equal(a,b):
    assert list(a)==list(b)
    for k in a:torch.testing.assert_close(a[k],b[k],rtol=0,atol=0)
def onnx_matches(path,value):
    graph=onnx.load(path);onnx.checker.check_model(graph)
    assert [node.op_type for node in graph.graph.node]==['Gemm','Tanh','Gemm']
    weights={x.name:numpy_helper.to_array(x) for x in graph.graph.initializer}
    assert sum(v.size for v in weights.values())==163
    for i,node in zip([0,2],[node for node in graph.graph.node if node.op_type=='Gemm']):
        assert next(a.i for a in node.attribute if a.name=='transB')==1
        np.testing.assert_array_equal(weights[node.input[1]],value[f'{i}.weight'].numpy())
        np.testing.assert_array_equal(weights[node.input[2]],value[f'{i}.bias'].numpy())
def function_dumps(path):
    return {n.name:ast.dump(n,include_attributes=False) for n in ast.parse(Path(path).read_text()).body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))}
def near(a,b):assert abs(a-b)<1e-12,(a,b)


def main():
    ppo=OUT/'ppo';distill=OUT/'distill';protocol_hash=digest(OUT/'protocol.json')
    verification=read(ppo/'verification.json');cool=read(ppo/'cool-amendment.json');dv=read(distill/'verification.json');da=read(distill/'amendment.json')
    assert verification['passed'] and dv['passed']
    assert digest(OUT/'ppo.py')==verification['source_sha256']=='8de451d1ffb125f1119c8af630906cf2b64150b4d7317ee5a6fa19e533d4bb39'
    assert protocol_hash==cool['unchanged_parent_protocol_sha256']==da['parent_protocol_sha256']
    assert digest(ppo/'candidates.json')==cool['unchanged_original_ppo_candidates_sha256']
    assert digest(ppo/'cool-amendment.json')==read(ppo/'cool-verification.json')['amendment_sha256']=='7ea1d6811b6c21c7322bb9629d5721b2e019871f30c967073f6bbfd26e64f3ea'
    assert digest(distill/'amendment.json')==dv['amendment_sha256']=='7159390bb950d223006956ffb41d51654df09cc05a69e99c5095e6121fc96ed3'
    lab_key=str((OUT/'lab.py').relative_to(ROOT));source_checks=[]
    for path,want in cool['source_sha256'].items():
        if path!=lab_key:assert digest(ROOT/path)==want
        source_checks.append(dict(path=path,current_sha256=digest(ROOT/path),registered_sha256=want,exact_match=digest(ROOT/path)==want))
    for path,want in da['sources'].items():
        assert digest(distill/'source'/path)==want
        if path!=lab_key:assert digest(ROOT/path)==want
        source_checks.append(dict(path=path,current_sha256=digest(ROOT/path),registered_sha256=want,exact_match=digest(ROOT/path)==want,snapshot_matches=True))
    old_functions=function_dumps(distill/'source'/lab_key);new_functions=function_dumps(OUT/'lab.py')
    changed_functions=[name for name in sorted(set(old_functions)|set(new_functions)) if old_functions.get(name)!=new_functions.get(name)]
    for helper in ['digest','save','config','load_start','field_score','rivals']:
        assert old_functions[helper]==new_functions[helper],helper
    for path,want in da['references'].items():assert digest(ROOT/path)==want
    manifests=['ppo/candidates.json','ppo/cool-candidates.json','distill/candidates.json'];pool=[];manifest_checks=[]
    for filename,expected in zip(manifests,[18,18,14]):
        candidates=read(OUT/filename);assert len(candidates)==expected
        for candidate in candidates:
            assert digest(OUT/candidate['path'])==candidate['sha256']
            assert candidate['hidden']==[16] and candidate['activation']=='tanh'
            candidate_state=state(OUT/candidate['path'])
            pool.append(dict(**candidate,state_sha256=state_hash(candidate_state)))
        manifest_checks.append(dict(path=filename,sha256=digest(OUT/filename),entries=len(candidates),all_recorded_artifact_hashes_match=True))
    assert len({p['name'] for p in pool})==50
    ppo_rows=[];baseline=None;artifact_hashes={};initial_states=[]
    for name in ['ppo-3em05','ppo-1em04','ppo-temp025','ppo-temp050']:
        folder=ppo/name;c=read(folder/'config.json');done=read(folder/'completed.json');history=lines(folder/'metrics.jsonl');optimization=lines(folder/'optimization.jsonl')
        assert digest(folder/'source.py')==c['source_sha256']==done['source_sha256']==digest(OUT/'ppo.py')
        if name.startswith('ppo-temp'):assert digest(folder/'followup-source.py')==digest(OUT/'ppo_cool.py')
        assert c['protocol_sha256']==protocol_hash
        assert [r['update'] for r in history]==list(range(0,161,20))
        assert [r['update'] for r in optimization]==list(range(1,169))
        assert [r['actor_update'] for r in optimization]==[0]*8+list(range(1,161))
        assert done['env_steps']==168*128*128==optimization[-1]['env_steps']==history[-1]['env_steps']
        arm_pool=[p for p in pool if p['path'].startswith('ppo/'+name+'/')]
        assert len(arm_pool)==9
        assert read(folder/'candidates.json')==[{k:v for k,v in item.items() if k!='state_sha256'} for item in arm_pool]
        for candidate,row in zip(arm_pool,history):
            assert candidate['actor_updates']==row['update'];near(candidate['best'],row['development_margin'])
        winner=max(history,key=lambda r:r['development_margin']);near(done['best_development_margin'],winner['development_margin'])
        best=state(folder/'best.pt');last=state(folder/'last.pt')
        equal(best,state(folder/f'u{winner["update"]:03d}.pt'));equal(last,state(folder/'u160.pt'))
        initial_states.append(state(folder/'u000.pt'))
        for filename,value in [('best.onnx',best),('last.onnx',last)]:onnx_matches(folder/filename,value)
        for filename in ['best.onnx','last.onnx','best.pt','last.pt','last-critic.pt']:artifact_hashes[str((folder/filename).relative_to(OUT))]=digest(folder/filename)
        if baseline is None:baseline=50*(1+history[0]['development_margin'])
        near(baseline,50*(1+history[0]['development_margin']))
        ppo_rows.append(dict(name=name,temperature=c['options']['temperature'],initial_learning_rate=c['learning_rate'],
            actor_rollout_updates=160,critic_only_warmup_updates=8,rollout_transitions=done['env_steps'],actor_rollout_transitions=160*128*128,
            actor_optimizer_steps=sum(r['epochs_ran']*8 for r in optimization if r['actor_update']),
            checkpoints=9,best_development_score_percent=50*(1+winner['development_margin']),best_update=winner['update'],
            final_development_score_percent=50*(1+history[-1]['development_margin'])))
    completion=read(distill/'completion.json');history=read(distill/'metrics.json');training=read(distill/'training.json');distill_rows=[]
    assert completion['passed'] and completion['teacher_weights_unchanged']
    assert [r['round'] for r in training]==list(range(1,25))
    assert completion['rollout_transitions']==24*128*64 and completion['gradient_steps_per_arm']==24*64
    assert completion['reflected_training_examples']==completion['original_training_examples_in_augmented_arm']==24*64*512
    for name in ['distill-plain','distill-reflect']:
        folder=distill/name;rows=[r for r in history if r['name']==name];assert [r['round'] for r in rows]==list(range(0,25,4))
        arm_pool=[p for p in pool if p['path'].startswith('distill/'+name+'/')];assert len(arm_pool)==7
        for candidate,row in zip(arm_pool,rows):assert candidate['round']==row['round'];near(candidate['best'],row['development_margin'])
        winner=max(rows,key=lambda r:r['development_margin']);best=state(folder/'best.pt');last=state(folder/'last.pt')
        equal(best,state(folder/f'{name}-r{winner["round"]}.pt'));equal(last,state(folder/f'{name}-r24.pt'))
        initial_states.append(state(folder/f'{name}-r0.pt'))
        for filename,value in [('best.onnx',best),('last.onnx',last)]:onnx_matches(folder/filename,value)
        for filename in ['best.onnx','last.onnx','best.pt','last.pt','optimizer.pt']:artifact_hashes[str((folder/filename).relative_to(OUT))]=digest(folder/filename)
        distill_rows.append(dict(name=name,rounds=24,actor_gradient_steps=1536,shared_rollout_transitions=196608,checkpoints=7,
            best_development_score_percent=50*(1+winner['development_margin']),best_round=winner['round'],
            final_development_score_percent=50*(1+rows[-1]['development_margin'])))
    for initial in initial_states[1:]:equal(initial,initial_states[0])
    summary=dict(passed=True,scope='PPO/distillation training and development artifacts only; no independent selection or confirmation outputs read',
        unique_training_arms=6,ppo_arms=ppo_rows,distillation_arms=distill_rows,starting_development_score_percent=baseline,
        totals=dict(candidate_manifest_entries=50,distinct_parameter_states=len({p['state_sha256'] for p in pool}),
            ppo_actor_rollout_updates=sum(r['actor_rollout_updates'] for r in ppo_rows),
            ppo_actor_optimizer_steps=sum(r['actor_optimizer_steps'] for r in ppo_rows),
            ppo_transitions=sum(r['rollout_transitions'] for r in ppo_rows),ppo_actor_rollout_transitions=sum(r['actor_rollout_transitions'] for r in ppo_rows),
            distillation_rounds_per_arm=24,distillation_gradient_steps_total=2*1536,distillation_shared_transitions=196608,
            total_simulated_transitions=sum(r['rollout_transitions'] for r in ppo_rows)+196608),
        recorded_manifest_hashes_verified=manifest_checks,source_checks=source_checks,
        current_lab_changed_functions=changed_functions,training_helpers_unchanged=True,initial_weights_identical_across_all_six_arms=True,
        all_candidates_finite_163_scalars=True,all_twelve_best_last_onnx_graphs_match_pt_weights_exactly=True,
        artifact_hash_inventory=artifact_hashes,
        caveats=['These are reused development-set scores, not independent evidence of improvement.',
            'One training random seed per arm; four PPO arms share seed10301, but differing sampling policies produce different trajectories.',
            'PPO temperature affects stochastic training only; deployment remains deterministic argmax.',
            'PPO actor rollout updates are distinct from optimizer steps and include no actor updates during eight critic-only warmups.',
            'Distillation shares one196608-transition bank between two arms; do not double-count this environment data.',
            'All six initial checkpoints share the same weights. Distinct state counts use canonical tensor bytes, not archive file hashes.',
            'Vertical reflection holds for integer v4 physics, not necessarily asymmetric policies, same-seed openings or first-argmax ties.',
            'No extra training, candidate replacement or held-out-result access occurred during this integrity audit.'])
    (ppo/'final-integrity.json').write_text(json.dumps(summary,indent=2,allow_nan=False)+'\n')
    (distill/'final-integrity.json').write_text(json.dumps({k:summary[k] for k in ['passed','scope','distillation_arms','training_helpers_unchanged','all_candidates_finite_163_scalars','caveats']},indent=2,allow_nan=False)+'\n')
    print(json.dumps({k:summary[k] for k in ['passed','unique_training_arms','ppo_arms','distillation_arms','totals','current_lab_changed_functions']},indent=2))


if __name__=='__main__':main()
