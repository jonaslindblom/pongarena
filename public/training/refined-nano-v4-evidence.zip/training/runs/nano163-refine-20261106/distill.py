"""Matched warm 447 distillation with optional training-only vertical reflection."""
from pathlib import Path
import copy,hashlib,importlib.util,json,subprocess,sys,time
import numpy as np
import torch
from torch import nn
from lab import OUT,ROOT,START,FIELD,RULES,config,load_start,rivals,export,evaluate_population,field_score
from policy import load_builtin,actions,OnnxPolicy
from pace_study import PaceArena,shot
from train_pace import broad_observations
from ppo import anchor_divergence

D=OUT/'distill'
COLS=[1,3,4,5]


def digest(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def write(path,obj):Path(path).write_text(json.dumps(obj,indent=2,allow_nan=False)+'\n')


def prepare():
    if (D/'amendment.json').exists():raise FileExistsError('Distillation already registered')
    D.mkdir(exist_ok=True)
    sources=[Path(__file__),OUT/'ppo.py',OUT/'lab.py',OUT/'population.py',
        ROOT/'training/runs/nano-depth163-20261106/depth.py',ROOT/'training/v4/reference.py',
        ROOT/'training/scripts/pace_study.py',ROOT/'training/scripts/env.py',ROOT/'training/scripts/policy.py']
    refs={str(START.relative_to(ROOT)):digest(START),
        **{f'public/models/{n}.onnx':digest(ROOT/f'public/models/{n}.onnx') for n in FIELD[:3]+['plain-nano-v4']}}
    amendment=dict(rationale='Test whether warm compression of the frozen447 teacher improves the current163 actor, and whether training-only vertical reflection improves generalization. No benefit is presumed.',
        registration_stage='Before training and before independent selection/confirmation access',
        parent_protocol_sha256=digest(OUT/'protocol.json'),architecture=[6,16,3],parameters=163,
        arms=[dict(name='distill-plain',reflection_fraction=0.),dict(name='distill-reflect',reflection_fraction=.5)],
        options=dict(seed=10501,rounds=24,gradient_steps=64,batch=1024,envs=128,horizon=64,
            replay_rounds=4,learning_rate=.0001,optimizer='Adam',max_grad_norm=1.,anchor_kl=.01,eval_every=4,
            teacher='plain-nano-v4',loss='0.5 hard-label CE +0.5 soft-target CE; softmax(teacher_logits/max(sample_std,0.5)); +0.01 KL(start_actor || student)',
            opponents='Uniform fixed six-opponent field; opponent and collecting arm sampled independently at each rally reset',
            collection='Shared reachable left/right observations from both current students; no synthetic observations; no teacher action mixing; no loop shortcut while weights change',
            matching='Same initial weights, shared replay data and exact shared minibatch IDs; augmented arm reflects exactly512/1024 randomly selected examples each step',
            augmentation='Negate normalized observation columns1,3,4,5; reverse teacher logits columns2,1,0; anchor evaluated on the actual inputs',
            training_interval=[0,1000000000],checkpoints='Initial and rounds4,8,12,16,20,24 per arm; all fourteen enter the candidate pool'),
        limitations=['Reflection is a property of integer-state v4 transition physics, not of every policy or the same-seed serve schedule.',
            'Arbitrary fractional contact states can hit asymmetric JavaScript rounding ties; training collects only reachable integer states.',
            'First-argmax tie-breaking does not commute with action reversal. Reflected hard labels use the same first-argmax convention after reversal.',
            'The fixed teacher and opponents can be asymmetric: reversed original logits are augmented targets, not claims about the teacher at reflected inputs.',
            'No runtime preprocessing, weight sharing, additional parameters or symmetry enforcement. Both exported actors remain ordinary163-scalar networks.'],
        references=refs,sources={str(p.relative_to(ROOT)):digest(p) for p in sources})
    write(D/'amendment.json',amendment)
    (D/'source').mkdir()
    for p in sources:
        target=D/'source'/p.relative_to(ROOT);target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(p.read_bytes())
    print('Registered',D/'amendment.json','sha256',digest(D/'amendment.json'),flush=True)


def mirror_frame(frame):
    result=copy.deepcopy(frame);result['y']=160-frame['y'];result['vy']=-frame['vy']
    result['paddles']=[160-p for p in frame['paddles']]
    result['scores']=[None if scores is None else scores[::-1] for scores in frame['scores']]
    return result


def verify():
    spec=importlib.util.spec_from_file_location('frozen_v4',ROOT/'training/v4/reference.py')
    ref=importlib.util.module_from_spec(spec);spec.loader.exec_module(ref)
    onehot=np.eye(3).tolist();frames=[];commands=[]
    # All integer offsets near the legal hit/miss boundary, both sides, all speeds and actions.
    for side in range(2):
        for speed in range(5,14):
            vx=(-1 if side==0 else 1)*speed
            for paddle in [15,80,145]:
                for action in range(3):
                    after=max(15,min(145,paddle+2*(action-1)))
                    for offset in range(-16,17):
                        for vy in [-9,0,9]:
                            y=after+offset-vy
                            if not (4<=y<=156 and 4<=after+offset<=156):continue
                            f=ref.serve(10500);f.update(x=(15 if side==0 else 345)-vx,y=y,vx=vx,vy=vy)
                            f['paddles'][side]=paddle;frames.append(f)
                            a=[1,1];a[side]=action;commands.append(a)
    for y in [4,5,155,156]:
        for vy in [-9,-1,0,1,9]:
            for tick in [0,1599]:
                for left in range(3):
                    for right in range(3):
                        f=ref.serve(10500);f.update(x=180,y=y,vx=13,vy=vy,paddles=[15,145],rallyTick=tick)
                        frames.append(f);commands.append([left,right])
    mirrors=[mirror_frame(f) for f in frames]
    commands=np.array(commands);engine=PaceArena(len(frames),RULES);engine.load(frames)
    reflected_engine=PaceArena(len(frames),RULES);reflected_engine.load(mirrors)
    outcome,hit=engine.step(commands);mirrored_outcome,mirrored_hit=reflected_engine.step(2-commands)
    np.testing.assert_array_equal(outcome,mirrored_outcome);np.testing.assert_array_equal(hit,mirrored_hit)
    np.testing.assert_array_equal(reflected_engine.ball[:,[0,2]],engine.ball[:,[0,2]])
    np.testing.assert_array_equal(reflected_engine.ball[:,1],160-engine.ball[:,1])
    np.testing.assert_array_equal(reflected_engine.ball[:,3],-engine.ball[:,3])
    np.testing.assert_array_equal(reflected_engine.paddles,160-engine.paddles)
    for i,(frame,mirrored,command) in enumerate(zip(frames,mirrors,commands)):
        scores=[onehot[a] for a in command];a=ref.advance(frame,scores)
        b=ref.advance(mirrored,[s[::-1] for s in scores]);assert b==mirror_frame(a)
        np.testing.assert_array_equal(engine.ball[i],[a[k] for k in ['x','y','vx','vy']])
        np.testing.assert_array_equal(engine.paddles[i],a['paddles'])
        assert outcome[i]==(a['actor'] if a['event']=='point' else 2 if a['event']=='draw' else -1)
        for side in range(2):
            x=np.array(ref.observation(a,side));x[COLS]*=-1
            np.testing.assert_array_equal(x,ref.observation(b,side))
    rng=np.random.default_rng(10503);reachable=0;returns=0
    for episode in range(64):
        f=ref.serve(int(rng.integers(0,1000000000)));g=mirror_frame(f)
        for tick in range(200):
            scores=[onehot[a] for a in rng.integers(0,3,2)]
            f=ref.advance(f,scores);g=ref.advance(g,[s[::-1] for s in scores]);assert g==mirror_frame(f)
            reachable+=1;returns+=f['event']=='return'
            if ref.ended_rally(f):break
    offsets=np.arange(-15,16)
    for incoming in range(5,14):
        speed,vertical=shot(offsets,incoming,RULES);other_speed,other_vertical=shot(-offsets,incoming,RULES)
        np.testing.assert_array_equal(speed,other_speed);np.testing.assert_array_equal(vertical,-other_vertical)
    # Repetition remains a repetition under this bijective state transform.
    loops=[ref.LoopDetector(),ref.LoopDetector()]
    contact=ref.serve(10500);contact.update(x=15,y=80,vx=6,vy=0,event='return')
    assert not loops[0].observe(contact) and not loops[1].observe(mirror_frame(contact))
    assert loops[0].observe(contact) and loops[1].observe(mirror_frame(contact))
    # Deliberately demonstrate limits rather than silently assuming arbitrary symmetry.
    assert ref.js_round(.5)!=-ref.js_round(-.5)
    assert ref.choice([1.,0.,1.])!=2-ref.choice([1.,0.,1.][::-1])
    x=torch.from_numpy(np.stack([engine.obs(0)[0],engine.obs(1)[0]]));twice=x.clone();twice[:,COLS]*=-1;twice[:,COLS]*=-1
    torch.testing.assert_close(x,twice,rtol=0,atol=0)
    logits=torch.tensor([[1.,2.,3.],[4.,2.,1.]])
    torch.testing.assert_close(logits.flip(-1).argmax(-1),2-logits.argmax(-1),rtol=0,atol=0)
    torch.testing.assert_close(logits.std(-1),logits.flip(-1).std(-1),rtol=0,atol=0)
    actor=load_start();assert sum(p.numel() for p in actor.parameters())==163
    export(actor,D/'verification.onnx','Unchanged163 actor; distillation verification')
    probes=broad_observations(np.random.default_rng(10505),4096)
    np.testing.assert_array_equal(actions(actor,probes),OnnxPolicy(D/'verification.onnx')(probes))
    subprocess.run(['node','--import','tsx','training/scripts/check_models.ts',str(D/'verification.onnx')],cwd=ROOT,check=True,stdout=subprocess.DEVNULL)
    result=dict(passed=True,amendment_sha256=digest(D/'amendment.json'),targeted_integer_scalar_vector_transitions=len(frames),
        mirrored_reachable_transitions=reachable,reachable_returns=returns,integer_return_antisymmetry_cases=9*31,
        loop_repetition_preserved=True,timeout_winner_and_clamp_symmetry=True,observation_and_label_involution=True,
        known_fractional_rounding_and_argmax_tie_limits_confirmed=True,native_torch_actions=4096,parameters=163)
    write(D/'verification.json',result);print('Physics/numerical verification',json.dumps(result),flush=True)


def train():
    amendment=json.loads((D/'amendment.json').read_text());cfg=config();c=amendment['options'];start_time=time.time()
    assert digest(OUT/'protocol.json')==amendment['parent_protocol_sha256']
    assert json.loads((D/'verification.json').read_text())['passed']
    for path,want in amendment['references'].items():assert digest(ROOT/path)==want,path
    for path,want in amendment['sources'].items():
        # Root may add candidate manifests to lab.select; its training helpers are snapshotted above.
        if path!=str((OUT/'lab.py').relative_to(ROOT)):assert digest(ROOT/path)==want,path
    if (D/'distill-plain').exists():raise FileExistsError('Fresh matched arms required')
    torch.set_num_threads(1);torch.manual_seed(c['seed'])
    rng=np.random.default_rng(c['seed']);augment_rng=np.random.default_rng(c['seed']+1)
    teacher=load_builtin(c['teacher']).requires_grad_(False);anchor=load_start().requires_grad_(False)
    teacher_before={k:v.clone() for k,v in teacher.state_dict().items()};references=rivals();models=[]
    for arm in amendment['arms']:
        m=load_start();folder=D/arm['name'];folder.mkdir()
        models.append(dict(**arm,net=m,opt=torch.optim.Adam(m.parameters(),lr=c['learning_rate']),folder=folder,best=-2.))
        assert sum(p.numel() for p in m.parameters())==163
    for key,value in models[0]['net'].state_dict().items():torch.testing.assert_close(value,models[1]['net'].state_dict()[key],rtol=0,atol=0)
    env=PaceArena(c['envs'],RULES,seed=c['seed'],loop_detection=False)
    model_ids=rng.integers(0,len(models),env.n);opponent_ids=rng.integers(0,len(references),env.n)
    replay=[];pool=[];history=[];training=[];batch_hash=hashlib.sha256();reflected_count=0;original_count=0
    def check(iteration):
        rows,_=evaluate_population([m['net'].state_dict() for m in models],'tanh',cfg['development_seeds'],references)
        for m,row in zip(models,rows):
            score=field_score(row);name=f'{m["name"]}-r{iteration}';path=f'distill/{m["name"]}/{name}.pt'
            torch.save(m['net'].state_dict(),OUT/path)
            method='Warm frozen447 distillation; '+('50% vertical-reflection training augmentation' if m['reflection_fraction'] else 'original observations')+'; .01 start-anchor KL'
            pool.append(dict(name=name,path=path,sha256=digest(OUT/path),hidden=[16],activation='tanh',method=method,best=score,round=iteration))
            history.append(dict(name=m['name'],round=iteration,development_margin=score,**row))
            if score>m['best']:
                m['best']=score;m['best_round']=iteration;torch.save(m['net'].state_dict(),m['folder']/'best.pt')
                export(m['net'],m['folder']/'best.onnx',method)
            print(name,'dev score',round(50*(score+1),4),flush=True)
        write(D/'metrics.json',history)
    check(0)
    for iteration in range(1,c['rounds']+1):
        observations=[]
        for _ in range(c['horizon']):
            x,y=env.obs(),env.obs(1);a=np.empty(env.n,int);b=np.empty(env.n,int)
            assert np.equal(env.ball,np.rint(env.ball)).all() and np.equal(env.paddles,np.rint(env.paddles)).all()
            for i,m in enumerate(models):
                mask=model_ids==i
                if mask.any():a[mask]=actions(m['net'],x[mask])
            for i,p in enumerate(references.values()):
                mask=opponent_ids==i
                if mask.any():b[mask]=actions(p,y[mask]) if isinstance(p,nn.Module) else p(y[mask])
            observations.extend([x,y]);terminal,_=env.step(np.stack([a,b],1));ids=np.flatnonzero(terminal>=0)
            env.reset(ids);model_ids[ids]=rng.integers(0,len(models),len(ids));opponent_ids[ids]=rng.integers(0,len(references),len(ids))
        replay.append(np.concatenate(observations));replay=replay[-c['replay_rounds']:];x=torch.from_numpy(np.concatenate(replay))
        with torch.no_grad():targets=torch.cat([teacher(part) for part in x.split(8192)])
        losses=np.zeros((len(models),3));tie_count=int((targets==targets.max(-1,keepdim=True).values).sum(-1).gt(1).sum())
        for _ in range(c['gradient_steps']):
            sampled=rng.integers(0,len(x),c['batch']);batch_hash.update(sampled.tobytes());ids=torch.from_numpy(sampled)
            reflected=torch.from_numpy(augment_rng.choice(c['batch'],c['batch']//2,replace=False));reflected_count+=len(reflected);original_count+=c['batch']-len(reflected)
            for i,m in enumerate(models):
                inputs=x[ids].clone();target=targets[ids].clone()
                if m['reflection_fraction']:
                    inputs[reflected[:,None],COLS]*=-1;target[reflected]=target[reflected].flip(-1)
                soft=(target/target.std(-1,keepdim=True).clamp_min(.5)).softmax(-1)
                logits=m['net'](inputs);hard=nn.functional.cross_entropy(logits,target.argmax(-1))
                soft_loss=(-soft*logits.log_softmax(-1)).sum(-1).mean()
                with torch.no_grad():anchor_logits=anchor(inputs)
                kl=anchor_divergence(anchor_logits,logits);loss=.5*hard+.5*soft_loss+c['anchor_kl']*kl
                if not torch.isfinite(loss):raise FloatingPointError('Nonfinite distillation loss')
                m['opt'].zero_grad();loss.backward();nn.utils.clip_grad_norm_(m['net'].parameters(),c['max_grad_norm'],error_if_nonfinite=True);m['opt'].step()
                losses[i]+=np.array([float(loss.detach()),float(kl.detach()),float(hard.detach())])
        training.append(dict(round=iteration,replay_observations=len(x),teacher_exact_top_ties=tie_count,
            losses={m['name']:dict(total=losses[i,0]/c['gradient_steps'],anchor_kl=losses[i,1]/c['gradient_steps'],hard_ce=losses[i,2]/c['gradient_steps']) for i,m in enumerate(models)}))
        write(D/'training.json',training)
        print('Distillation round',iteration,'losses',np.round(losses[:,0]/c['gradient_steps'],4).tolist(),flush=True)
        if iteration%c['eval_every']==0:check(iteration)
    for key,value in teacher.state_dict().items():torch.testing.assert_close(value,teacher_before[key],rtol=0,atol=0)
    paths=[];probes=broad_observations(np.random.default_rng(10507),4096)
    for m in models:
        torch.save(m['net'].state_dict(),m['folder']/'last.pt');torch.save(m['opt'].state_dict(),m['folder']/'optimizer.pt')
        export(m['net'],m['folder']/'last.onnx','Warm447 distillation; '+m['name'])
        np.testing.assert_array_equal(actions(m['net'],probes),OnnxPolicy(m['folder']/'last.onnx')(probes))
        best=load_start();best.load_state_dict(torch.load(m['folder']/'best.pt',weights_only=True))
        np.testing.assert_array_equal(actions(best,probes),OnnxPolicy(m['folder']/'best.onnx')(probes))
        paths.extend([str(m['folder']/'last.onnx'),str(m['folder']/'best.onnx')])
    subprocess.run(['node','--import','tsx','training/scripts/check_models.ts',*paths],cwd=ROOT,check=True,stdout=subprocess.DEVNULL)
    for candidate in pool:
        state=torch.load(OUT/candidate['path'],weights_only=True)
        assert sum(v.numel() for v in state.values())==163 and all(torch.isfinite(v).all() for v in state.values())
        assert digest(OUT/candidate['path'])==candidate['sha256']
    assert len(pool)==14
    write(D/'candidates.json',pool)
    result=dict(passed=True,candidates=len(pool),shared_minibatch_indices_sha256=batch_hash.hexdigest(),
        reflected_training_examples=reflected_count,original_training_examples_in_augmented_arm=original_count,
        rollout_transitions=c['rounds']*c['envs']*c['horizon'],gradient_steps_per_arm=c['rounds']*c['gradient_steps'],
        teacher_weights_unchanged=True,parameters=163,native_torch_action_checks=4*len(probes),active_graph_contract=True,
        seconds=time.time()-start_time,arms=[dict(name=m['name'],best_development_margin=m['best'],best_round=m['best_round']) for m in models])
    write(D/'completion.json',result);print('Completed matched distillation',json.dumps(result),flush=True)


if __name__=='__main__':
    for stage in sys.argv[1:]:globals()[stage]()
