"""Check frozen model export and prepare identical browser/native action probes."""
import json
import numpy as np
import torch
from lab import ROOT, OUT, START, load_start, load_file, digest, save
from policy import OnnxPolicy
from train_pace import broad_observations

winner = json.loads((OUT / 'frozen-winner.json').read_text())
assert digest(OUT / 'winner.onnx') == winner['onnx_sha256']
observations = broad_observations(np.random.default_rng(9611), 4096)
models = {
    'winner': OUT / 'winner.onnx',
    'start': START,
    'nano447': ROOT / 'public/models/plain-nano-v4.onnx',
}
probes = {'observations': observations.tolist(), 'models': {}}
checks = {}
for name, path in models.items():
    actor = load_file(path)
    if name == 'winner':
        original = load_start()
        original.load_state_dict(torch.load(OUT / winner['path'], weights_only=True))
        assert all(torch.equal(a, b) for a, b in zip(actor.parameters(), original.parameters()))
    with torch.no_grad():
        expected = actor(torch.from_numpy(observations)).argmax(-1).numpy()
    native = OnnxPolicy(path)(observations)
    mismatches = int(np.count_nonzero(expected != native))
    assert mismatches == 0, (name, mismatches)
    params = sum(p.numel() for p in actor.parameters())
    if name in ['winner', 'start']:
        assert params == 163
    url = '/models/' + path.name if name == 'nano447' else '/' + str(path.relative_to(ROOT))
    probes['models'][name] = dict(file=url, sha256=digest(path), parameters=params, actions=native.tolist())
    checks[name] = dict(sha256=digest(path), parameters=params, probes=len(native), action_mismatches=mismatches)
save('runtime-probes.json', probes)
save('native-runtime-verification.json', checks)
(OUT / 'browser-check.html').write_text('<!doctype html><meta charset="utf-8"><link rel="icon" href="data:,"><title>Frozen Nano runtime verification</title><p>Frozen Nano runtime verification</p>\n')
print(json.dumps(checks, indent=2))
