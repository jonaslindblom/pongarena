"""Outcome-only PPO continuation of the frozen 163-scalar Tanh actor.

Six raw actor inputs and deterministic argmax deployment. Opponent identity,
remaining rally time, critic weights and sampling are training-only.
"""
from pathlib import Path
import sys,json,time,hashlib
ROOT=Path(__file__).resolve().parents[3]
OUT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'training/scripts'))
import numpy as np
import torch
from torch import nn
from torch.distributions import Categorical
from policy import actions,OnnxPolicy
from pace_study import PaceArena
from train_pace import broad_observations


def advantages(rewards,dones,values,next_value,gamma,lam):
    """Bootstrap rollout cuts but stop credit at scored/drawn rally boundaries."""
    result=torch.empty_like(rewards);gae=torch.zeros_like(next_value)
    for t in reversed(range(len(rewards))):
        alive=(~dones[t]).to(values.dtype)
        delta=rewards[t]+gamma*next_value*alive-values[t]
        gae=delta+gamma*lam*alive*gae
        result[t]=gae;next_value=values[t]
    return result,result+values


def anchor_divergence(reference_logits,logits):
    # Log-softmax avoids false infinity when float32 probabilities underflow.
    reference_logp=reference_logits.log_softmax(-1)
    return (reference_logp.exp()*(reference_logp-logits.log_softmax(-1))).sum(-1).mean()


def digest(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def write(path,value):Path(path).write_text(json.dumps(value,indent=2,allow_nan=False)+'\n')


def verify():
    from lab import load_start,export
    torch.set_num_threads(1)
    rewards=torch.tensor([[0.,0.],[1.,0.],[0.,-1.]],dtype=torch.float64)
    dones=torch.tensor([[False,False],[True,False],[False,True]])
    values=torch.tensor([[.2,.3],[.4,.5],[.6,.7]],dtype=torch.float64)
    next_value=torch.tensor([.8,.9],dtype=torch.float64)
    adv,returns=advantages(rewards,dones,values,next_value,.9,1.)
    expected=torch.tensor([[.9,-.81],[1.,-.9],[.72,-1.]],dtype=torch.float64)
    torch.testing.assert_close(returns,expected,rtol=0,atol=1e-12)
    torch.testing.assert_close(adv,expected-values,rtol=0,atol=1e-12)
    # A terminal draw must not bootstrap a reset state's value.
    _,draw=advantages(torch.zeros(1,1),torch.ones(1,1,dtype=torch.bool),torch.zeros(1,1),torch.tensor([100.]),1.,.995)
    assert draw.item()==0
    ref=torch.tensor([[1000.,-1000.,0.]])
    logits=torch.tensor([[-1000.,1000.,0.]],requires_grad=True)
    kl=anchor_divergence(ref,logits);assert torch.isfinite(kl) and abs(kl.item()-2000)<1e-3
    kl.backward();assert torch.isfinite(logits.grad).all()
    m=load_start();assert sum(p.numel() for p in m.parameters())==163
    x=torch.from_numpy(broad_observations(np.random.default_rng(10101),4096))
    with torch.no_grad():
        scores=m(x);dist=Categorical(logits=scores);sample=dist.sample();old_lp=dist.log_prob(sample)
        torch.testing.assert_close(old_lp,scores.log_softmax(-1).gather(1,sample[:,None]).squeeze(1))
        ratio=(dist.log_prob(sample)-old_lp).exp()
        torch.testing.assert_close(ratio,torch.ones_like(ratio),rtol=0,atol=0)
        assert torch.isfinite(dist.entropy()).all()
    output=OUT/'ppo';output.mkdir(exist_ok=True)
    export(m,output/'verification.onnx','Unchanged starting actor for PPO numerical checks')
    native=OnnxPolicy(output/'verification.onnx')
    np.testing.assert_array_equal(actions(m,x.numpy()),native(x.numpy()))
    import subprocess
    subprocess.run(['node','--import','tsx','training/scripts/check_models.ts',str(output/'verification.onnx')],cwd=ROOT,check=True,stdout=subprocess.DEVNULL)
    result=dict(passed=True,gae_terminal_and_rollout_boundary=True,terminal_draw_does_not_bootstrap=True,
        finite_extreme_anchor_kl=True,stored_log_probability_agreement=True,initial_ratio_exactly_one=True,
        native_torch_actions=4096,parameters=163,source_sha256=digest(__file__))
    write(output/'verification.json',result)
    print('PPO verification',json.dumps(result),flush=True)


def train_arm(name,learning_rate,cfg):
    from lab import load_start,rivals,RULES,FIELD,export,evaluate_population,field_score
    options=cfg['ppo'];folder=OUT/'ppo'/name
    if folder.exists():raise FileExistsError(f'Fresh PPO arm required: {folder}')
    folder.mkdir(parents=True)
    seed=options.get('seed',10301)
    torch.set_num_threads(1);torch.manual_seed(seed);rng=np.random.default_rng(seed)
    actor=load_start();anchor=load_start().requires_grad_(False)
    assert sum(p.numel() for p in actor.parameters())==163
    initial={k:v.clone() for k,v in actor.state_dict().items()}
    references=rivals();assert list(references)==list(FIELD)
    critic_inputs=7+len(FIELD)
    critic=nn.Sequential(nn.Linear(critic_inputs,64),nn.Tanh(),nn.Linear(64,64),nn.Tanh(),nn.Linear(64,1))
    for layer in critic:
        if isinstance(layer,nn.Linear):
            nn.init.orthogonal_(layer.weight,gain=np.sqrt(2));nn.init.zeros_(layer.bias)
    nn.init.orthogonal_(critic[-1].weight,gain=1.)
    actor_optimizer=torch.optim.Adam(actor.parameters(),lr=learning_rate,eps=1e-5)
    critic_optimizer=torch.optim.Adam(critic.parameters(),lr=3e-4,eps=1e-5)
    env=PaceArena(options['envs'],RULES,seed=seed,loop_detection=False)
    opponent_ids=rng.integers(0,len(FIELD),env.n)
    source=Path(__file__).read_bytes();(folder/'source.py').write_bytes(source)
    record=dict(name=name,learning_rate=learning_rate,seed=seed,options=options,
        architecture=[6,16,3],parameters=163,critic_architecture=[critic_inputs,64,64,1],
        critic_inputs='six observations + six fixed opponent indicators + remaining rally fraction; training-only',
        opponent_sampling='uniform over the fixed six opponents, refreshed at every rally',
        reward='terminal +1 win, -1 loss, 0 draw; no hit shaping or teacher labels',
        training_loop_detection=False,training_seed_interval=[0,1000000000],
        protocol_sha256=digest(OUT/'protocol.json'),source_sha256=digest(__file__),
        selection='Every fixed-interval checkpoint retained; best.pt chosen by six-field development mean only. Independent selection is owned by root study.',
        critic_learning_rate=.0003,minibatch=2048,actor_learning_rate_schedule='linear decay to 20% across actor updates')
    write(folder/'config.json',record)
    started=time.monotonic();total=0;best=-np.inf;candidates=[]
    dev=cfg['development_seeds']
    assert all(seed>=1000000000 for seed in dev)

    def critic_input(obs):
        return torch.from_numpy(np.concatenate([obs,np.eye(len(FIELD),dtype=np.float32)[opponent_ids],
            ((1600-env.ticks)/1600).astype(np.float32)[:,None]],axis=1))

    def opposing(obs):
        result=np.empty(env.n,dtype=int)
        for i,p in enumerate(references.values()):
            mask=opponent_ids==i
            if mask.any():result[mask]=actions(p,obs[mask]) if isinstance(p,nn.Module) else p(obs[mask])
        return result

    def evaluate(actor_updates,diagnostics):
        nonlocal best
        rows,_=evaluate_population([actor.state_dict()],'tanh',dev,references)
        score=field_score(rows[0]);path=folder/f'u{actor_updates:03d}.pt'
        torch.save(actor.state_dict(),path)
        entry=dict(name=f'{name}-u{actor_updates:03d}',path=str(path.relative_to(OUT)),sha256=digest(path),
            hidden=[16],activation='tanh',method=f'Outcome-only PPO continuation, actor lr={learning_rate:g}, update={actor_updates}',
            best=score,development_margin=score,actor_updates=actor_updates)
        candidates.append(entry)
        row=dict(update=actor_updates,env_steps=total,seconds=time.monotonic()-started,development_margin=score,**rows[0],**diagnostics)
        with (folder/'metrics.jsonl').open('a') as stream:stream.write(json.dumps(row,allow_nan=False)+'\n')
        if score>best:
            best=score;torch.save(actor.state_dict(),folder/'best.pt');export(actor,folder/'best.onnx',entry['method']);write(folder/'selection.json',row)
        torch.save(actor.state_dict(),folder/'last.pt');torch.save(critic.state_dict(),folder/'last-critic.pt')
        write(folder/'candidates.json',candidates)
        print(name,'actor update',actor_updates,'field score',round((score+1)*50,2),'best',round((best+1)*50,2),flush=True)

    evaluate(0,{})
    warmup=options['critic_warmup_updates'];updates=options['updates']
    for update in range(1,warmup+updates+1):
        xs,cs,selected,logps,values,rewards,dones=[],[],[],[],[],[],[]
        for _ in range(options['horizon']):
            obs=env.obs();x,c=torch.from_numpy(obs),critic_input(obs)
            with torch.no_grad():
                distribution=Categorical(logits=actor(x)/options['temperature']);action=distribution.sample()
                value=critic(c).squeeze(-1);logp=distribution.log_prob(action)
            terminal,_=env.step(np.stack([action.numpy(),opposing(env.obs(1))],1))
            reward=(terminal==0).astype(np.float32)-(terminal==1).astype(np.float32)
            xs.append(x);cs.append(c);selected.append(action);logps.append(logp);values.append(value)
            rewards.append(torch.from_numpy(reward));dones.append(torch.from_numpy(terminal>=0))
            reset=np.flatnonzero(terminal>=0);env.reset(reset);opponent_ids[reset]=rng.integers(0,len(FIELD),len(reset))
        total+=env.n*options['horizon']
        x,c,action,old_lp,old_value,reward,done=map(torch.stack,[xs,cs,selected,logps,values,rewards,dones])
        with torch.no_grad():adv,returns=advantages(reward,done,old_value,critic(critic_input(env.obs())).squeeze(-1),options['gamma'],options['gae_lambda'])
        x,c,action,old_lp,old_value=x.reshape(-1,6),c.reshape(-1,critic_inputs),action.flatten(),old_lp.flatten(),old_value.flatten()
        adv,returns=adv.flatten(),returns.flatten();explained=float(1-(returns-old_value).var()/(returns.var()+1e-8))
        adv=(adv-adv.mean())/(adv.std(unbiased=False)+1e-8)
        actor_update=max(0,update-warmup)
        actor_optimizer.param_groups[0]['lr']=learning_rate*(1-.8*max(0,actor_update-1)/updates)
        with torch.no_grad():anchor_logits=torch.cat([anchor(part)/options['temperature'] for part in x.split(4096)])
        totals=np.zeros(6);seen=0;epochs_ran=0
        for _ in range(options['epochs']):
            epoch_kls=[];epochs_ran+=1
            for ids in torch.randperm(len(x)).split(2048):
                dist=Categorical(logits=actor(x[ids])/options['temperature']);logratio=dist.log_prob(action[ids])-old_lp[ids];ratio=logratio.exp()
                policy_loss=torch.maximum(-adv[ids]*ratio,-adv[ids]*ratio.clamp(1-options['clip'],1+options['clip'])).mean()
                prediction=critic(c[ids]).squeeze(-1);clipped=old_value[ids]+(prediction-old_value[ids]).clamp(-.2,.2)
                value_loss=.5*torch.maximum((prediction-returns[ids]).square(),(clipped-returns[ids]).square()).mean()
                entropy=dist.entropy().mean();anchor_loss=anchor_divergence(anchor_logits[ids],dist.logits);approx_kl=((ratio-1)-logratio).mean()
                loss=.5*value_loss
                if actor_update:loss=loss+policy_loss-options['entropy']*entropy+options['anchor_kl']*anchor_loss
                if not torch.isfinite(loss):raise FloatingPointError('Nonfinite PPO objective')
                actor_optimizer.zero_grad();critic_optimizer.zero_grad();loss.backward()
                nn.utils.clip_grad_norm_(critic.parameters(),options['max_grad_norm'],error_if_nonfinite=True);critic_optimizer.step()
                if actor_update:
                    nn.utils.clip_grad_norm_(actor.parameters(),options['max_grad_norm'],error_if_nonfinite=True);actor_optimizer.step()
                measurements=[policy_loss,value_loss,entropy,anchor_loss,approx_kl,((ratio-1).abs()>options['clip']).float().mean()]
                totals+=np.array([float(v.detach()) for v in measurements])*len(ids);seen+=len(ids);epoch_kls.append(float(approx_kl.detach()))
            if np.mean(epoch_kls)>options['target_kl']:break
        if update==warmup:
            for k,v in actor.state_dict().items():torch.testing.assert_close(v,initial[k],rtol=0,atol=0)
        diagnostics=dict(zip(['policy_loss','value_loss','entropy','anchor_kl','approximate_kl','clip_fraction'],(totals/seen).tolist()))
        diagnostics.update(explained_variance=explained,rollout_reward=float(reward.sum()),finished_rallies=int(done.sum()),learning_rate=actor_optimizer.param_groups[0]['lr'],epochs_ran=epochs_ran)
        with (folder/'optimization.jsonl').open('a') as stream:stream.write(json.dumps(dict(update=update,actor_update=actor_update,env_steps=total,**diagnostics),allow_nan=False)+'\n')
        if actor_update and (actor_update%options['eval_every']==0 or actor_update==updates):evaluate(actor_update,diagnostics)
        elif update%10==0:print(name,'update',update,'actor',actor_update,'finished rallies',int(done.sum()),flush=True)
    export(actor,folder/'last.onnx',f'Outcome-only PPO continuation, final lr arm={learning_rate:g}')
    probe=broad_observations(np.random.default_rng(seed+3000),4096)
    np.testing.assert_array_equal(actions(actor,probe),OnnxPolicy(folder/'last.onnx')(probe))
    write(folder/'completed.json',dict(seconds=time.monotonic()-started,env_steps=total,actor_updates=updates,critic_warmup=warmup,
        best_development_margin=best,final_native_torch_action_probes=4096,source_sha256=digest(__file__)))
    print('Completed',name,'seconds',round(time.monotonic()-started,1),flush=True)
    return candidates


def train():
    from lab import config
    cfg=config();options=cfg['ppo'];all_candidates=[]
    assert options['gamma']==1. and options['gae_lambda']==.995 and options['critic_warmup_updates']==8
    assert options['temperature']==1.
    assert json.loads((OUT/'ppo/verification.json').read_text())['passed']
    for rate in options['learning_rates']:
        name='ppo-'+format(rate,'.0e').replace('-','m').replace('+','p')
        all_candidates.extend(train_arm(name,rate,cfg))
    write(OUT/'ppo/candidates.json',all_candidates)
    print('PPO candidate pool saved:',len(all_candidates),flush=True)


if __name__=='__main__':
    for stage in sys.argv[1:]:globals()[stage]()
