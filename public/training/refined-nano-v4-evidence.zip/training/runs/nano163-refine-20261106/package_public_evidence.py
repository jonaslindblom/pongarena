"""Package the selected Refined Nano and its two frozen evaluation studies."""
from pathlib import Path
import hashlib
import json
import zipfile

ROOT = Path(__file__).resolve().parents[3]
REFINE = ROOT / 'training/runs/nano163-refine-20261106'
COMPARE = ROOT / 'training/runs/trained163-vs-quill-plus-20261106'
OUTPUT = ROOT / 'public/training/refined-nano-v4-evidence.zip'
EXPECTED = '3772611174d50c181668ed5f4984b65d6e8fbaad6b438a942941ad9901497633'
entries = {}


def add(path):
    path = Path(path)
    assert path.is_file(), path
    name = str(path.relative_to(ROOT))
    data = path.read_bytes()
    if name in entries:
        assert entries[name] == data
    entries[name] = data


def digest(data):
    return hashlib.sha256(data).hexdigest()


assert digest((ROOT / 'public/models/refined-nano-v4.onnx').read_bytes()) == EXPECTED
for name in [
    'Nano-163-Refined-Tanh.onnx', 'winner.onnx', 'unchanged.pt',
    'protocol.json', 'frozen-pool.json', 'selection.json', 'frozen-winner.json',
    'confirmation.json', 'RESULTS.txt', 'comparison.png', 'seed-audit.json',
    'amendment-audit.json', 'final-audit.json', 'selection-amendment.json',
    'distill-selection-amendment.json', 'confirmation-ci-amendment.json',
    'native-runtime-verification.json', 'browser-runtime-verification.json',
    'verification.json', 'lab.py', 'nano_cma.py', 'population.py', 'ppo.py',
    'ppo_cool.py', 'distill.py', 'report.py', 'verify_export.py',
    'package_public_evidence.py', 'cma/cma-fine-g40.pt',
    'cma/candidates.json', 'cma/coordinates.npz', 'cma/fine-checkpoint.json',
]:
    add(REFINE / name)
for path in sorted((REFINE / 'cma').glob('*-metrics.json')):
    add(path)
for folder in ['source', 'ppo', 'distill']:
    for path in sorted((REFINE / folder).rglob('*')):
        if path.is_file() and path.suffix in {'.py', '.json', '.jsonl', '.txt'}:
            add(path)
for path in sorted(COMPARE.rglob('*')):
    if path.is_file() and path.suffix in {'.py', '.json', '.onnx', '.txt'}:
        add(path)
for name in ['Nano-163-1hidden-Tanh.onnx', 'depth.py', 'population.py', 'nano_cma.py', 'protocol.json']:
    add(ROOT / 'training/runs/nano-depth163-20261106' / name)
for path in sorted((ROOT / 'training/scripts').glob('*.py')):
    add(path)
for name in [
    'training/scripts/check_models.ts', 'training/scripts/check_replays.ts',
    'training/v3/reference.py', 'training/v4/reference.py',
    'training/requirements.txt', 'training/requirements-lock.txt',
    'src/validate.ts', 'src/game.ts', 'src/rules.ts', 'src/brain.ts',
    'src/scripted.ts', 'src/competition.ts', 'package.json', 'package-lock.json',
    'public/models/refined-nano-v4.onnx', 'public/models/plain-nano-v4.onnx',
    'public/models/pacer-v4.onnx', 'public/models/robust-strong-v4.onnx',
    'public/models/vector-nano-v4.onnx', 'public/models/quill-plus-v4.onnx',
    'public/training/refined-nano-v4.html',
]:
    add(ROOT / name)

entries['README.txt'] = '''REFINED NANO V4 — COMPACT EVIDENCE SNAPSHOT

Released model: public/models/refined-nano-v4.onnx
SHA-256: 3772611174d50c181668ed5f4984b65d6e8fbaad6b438a942941ad9901497633
Architecture: 6 -> 16 -> 3, Tanh; 163 scalar parameters, 144 MACs.
Selected checkpoint: training/runs/nano163-refine-20261106/cma/cma-fine-g40.pt

TWO SEPARATE FROZEN COMPARISONS
1. nano163-refine-20261106: 24 development, 96 selection and 256 confirmation
   paired seeds. The retained candidate's six-opponent confirmation mean is
   30.46%, versus 26.62% for unchanged trained163 and 39.80% for Plain Nano447.
   Gain versus unchanged163: +3.84pp, 95% CI +3.04 to +4.61.
2. trained163-vs-quill-plus-20261106: a later fixed-model comparison on 256
   separate paired seeds, with no training or checkpoint selection. Quill Plus
   scores 48.90% against the common field versus 30.02% for Refined Nano.
   Quill wins the direct games434/46/32 W/L/D. Refined scores better on Attacker.
Different seed sets explain the two Refined Nano field averages. These six-opponent
averages must not be compared directly with the older ten-opponent Quill report.

CONTENTS
The archive preserves the selected ONNX and Torch checkpoint; the exact starting
actor and reference weights; both protocols; complete selection/confirmation
results; all thirteen Quill comparison files with per-rally outcomes; development
metrics and candidate manifests for all ten follow-up arms; training/evaluation
code, frozen source snapshots and amendment records; native/browser verification;
seed and final integrity audits; and the public report. Original repository-relative
paths are retained. SHA256.json hashes every other entry, including this README.

SCOPE AND LIMITATIONS
This is a compact evidence/evaluation snapshot, not a full training-history backup.
Discarded checkpoint weights, optimizer states, large runtime probe arrays, logs,
redundant progress files and older study trajectories are omitted. Candidate and
integrity manifests can reference those omitted files. The original local run
directories retain all search artifacts. Native/browser verification summaries and
the deterministic probe-generation script are included; the generated probe arrays
are not. The earlier depth-study helper code, protocol and starting ONNX are included
for provenance, but that older study is not bundled in full.

Historical release.json is deliberately omitted: its audit_sha256 predates the final
audit's appended report review. Historical protocol/audit/result files are preserved
byte-for-byte. The bundle manifest gives their actual current hashes; it does not
rewrite original provenance claims. This packaging step does not alter any model,
training result, seed set or source snapshot. Earlier reports saying the experiment
made no catalog edits describe the experiment at that time; the later publication
adds the frozen model to the app.

VALIDATION AND REPRODUCTION
Extract into a separate directory, never over the live repository. Python dependency
versions are recorded in training/requirements-lock.txt; Node dependencies are in
package-lock.json. With those dependencies installed, validate the frozen model:
  node --import tsx training/scripts/check_models.ts public/models/refined-nano-v4.onnx

The original comparison files are immutable evidence. To rerun the Quill comparison,
create a new sibling directory under training/runs/, copy compare.py, protocol.json
and models/ from trained163-vs-quill-plus-20261106 into it, and run its compare.py with
the arguments 'run report'. Keep the original included source files at their recorded
paths: the protocol checks their hashes. This recreates matches from frozen models
and serves; it does not need discarded training checkpoints. The original scripts
intentionally refuse to overwrite completed results. Full original checkpoint
selection or training-history replay requires the omitted local search artifacts.

Primary reported intervals use10,000 whole-paired-seed bootstrap samples. Raw evaluator
rows retain their original2,000-sample intervals. The confirmation CI correction and
its source hash chain are included. Distinct seed IDs can repeat physical openings,
and the seed audits cover recorded evidence, not unlogged historical training.
'''.replace('games434', 'games 434').replace('use10,000', 'use 10,000').replace('original2,000', 'original 2,000').encode()

entries['BUNDLE.json'] = (json.dumps(dict(
    model='Refined Nano v4', model_sha256=EXPECTED, parameters=163, macs=144,
    architecture=[6, 16, 3], activation='Tanh',
    scope='Compact selected-model evidence and evaluation snapshot; omitted search weights and optimizer states remain local.',
    selected_checkpoint='training/runs/nano163-refine-20261106/cma/cma-fine-g40.pt',
    studies=['training/runs/nano163-refine-20261106', 'training/runs/trained163-vs-quill-plus-20261106'],
    historical_artifacts_modified=False, historical_release_json_included=False,
    manifest='SHA256.json', manifest_scope='Every archive entry except SHA256.json itself',
), indent=2) + '\n').encode()
entries['SHA256.json'] = (json.dumps({name: digest(data) for name, data in sorted(entries.items())}, indent=2) + '\n').encode()

with zipfile.ZipFile(OUTPUT, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for name, data in sorted(entries.items()):
        info = zipfile.ZipInfo(name, date_time=(2026, 11, 6, 0, 0, 0))
        info.compress_type = zipfile.ZIP_DEFLATED
        info.external_attr = 0o644 << 16
        archive.writestr(info, data, compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)

with zipfile.ZipFile(OUTPUT) as archive:
    assert archive.testzip() is None
    manifest = json.loads(archive.read('SHA256.json'))
    assert set(manifest) == set(archive.namelist()) - {'SHA256.json'}
    assert all(digest(archive.read(name)) == sha for name, sha in manifest.items())
    assert archive.read('public/models/refined-nano-v4.onnx') == archive.read('training/runs/nano163-refine-20261106/winner.onnx')
print(json.dumps(dict(path=str(OUTPUT.relative_to(ROOT)), bytes=OUTPUT.stat().st_size,
                     sha256=digest(OUTPUT.read_bytes()), entries=len(entries)), indent=2))
