import numpy as np
import torch
from torch import nn
from competition_eval import openings
from pace_study import PaceArena, CONFIGS
from policy import actions
RULES=CONFIGS["pace13-v9-scaled"]

class Population:
    def __init__(self,states,activation):
        self.size=len(states);self.activation=activation
        ids=sorted(int(k.split('.')[0]) for k in states[0] if k.endswith('.weight'))
        self.layers=[(torch.stack([s[f'{i}.weight'] for s in states]).transpose(1,2),
            torch.stack([s[f'{i}.bias'] for s in states])[:,None]) for i in ids]

    def actions(self,obs,opponent_count):
        n=len(obs)//(opponent_count*self.size)
        x=torch.from_numpy(obs.reshape(opponent_count,self.size,n,6).transpose(1,0,2,3).reshape(self.size,opponent_count*n,6))
        with torch.no_grad():
            for i,(weight,bias) in enumerate(self.layers):
                x=torch.bmm(x,weight)+bias
                if i<len(self.layers)-1:x=x.tanh() if self.activation=='tanh' else x.relu()
        return x.argmax(-1).numpy().reshape(self.size,opponent_count,n).transpose(1,0,2).reshape(-1)


def evaluate_population(states,activation,seeds,rivals):
    population=Population(states,activation)
    frames,sides=openings(seeds);width=len(frames);count=len(rivals)
    frames=frames*(count*population.size);sides=np.tile(sides,count*population.size)
    codes=np.repeat(np.arange(count),population.size*width)
    env=PaceArena(len(frames),RULES,loop_detection=True);env.load(frames)
    outcome=np.full(env.n,-1);decisions=0
    for _ in range(1600):
        active=outcome<0
        left,right=env.obs(),env.obs(1)
        ours=np.where(sides[:,None]==0,left,right);theirs=np.where(sides[:,None]==0,right,left)
        a,b=population.actions(ours,count),np.ones(env.n,dtype=int)
        for code,policy in enumerate(rivals.values()):
            ix=active&(codes==code)
            if ix.any():b[ix]=actions(policy,theirs[ix]) if isinstance(policy,nn.Module) else policy(theirs[ix])
        terminal,_=env.step(np.stack([np.where(sides==0,a,b),np.where(sides==0,b,a)],1),active)
        done=active&(terminal>=0);outcome[done]=terminal[done];decisions+=int(active.sum())
        if (outcome>=0).all():break
    assert (outcome>=0).all()
    points=np.where(outcome==sides,1,np.where(outcome==1-sides,-1,0)).reshape(count,population.size,width)
    return [dict(mean_margin=float(points[:,i].mean()),opponents={name:float(points[j,i].mean()) for j,name in enumerate(rivals)}) for i in range(population.size)],decisions

