"""Positive-weight, full-covariance CMA-ES for plain Nano policy weights.

Equations follow Hansen's tutorial, Appendix C (rank-one + rank-mu update and
cumulative step-size adaptation): https://arxiv.org/abs/1604.00772 . This omits
active negative covariance weights, elitism, automatic restarts and flat-fitness
heuristics. Every generation uses a fresh eigendecomposition. The caller owns
the objective, held-out evaluation, restarts and incumbent policy selection.
"""
import copy

import numpy as np


class CMA:
    def __init__(self, mean, sigma, seed, population_size, *, sigma_min=1e-12, sigma_max=100.):
        mean=np.asarray(mean,dtype=np.float64)
        if mean.ndim!=1 or not len(mean) or not np.isfinite(mean).all():
            raise ValueError('Mean must be a nonempty finite vector.')
        if isinstance(population_size,(bool,np.bool_)) or not isinstance(population_size,(int,np.integer)) or population_size<4:
            raise ValueError('Population size must be an integer >=4.')
        if not all(np.isfinite(v) for v in [sigma,sigma_min,sigma_max]) or not 0<sigma_min<=sigma<=sigma_max:
            raise ValueError('Require finite 0 < sigma_min <= sigma <= sigma_max.')
        self.mean=mean.copy()
        self.sigma=float(sigma)
        self.sigma_min,self.sigma_max=float(sigma_min),float(sigma_max)
        self.n=len(mean)
        self.population_size=int(population_size)
        self.mu=self.population_size//2
        weights=np.log((self.population_size+1)/2)-np.log(np.arange(1,self.mu+1))
        self.weights=weights/weights.sum()
        self.mu_eff=float(1/np.square(self.weights).sum())
        n,m=self.n,self.mu_eff
        self.cc=(4+m/n)/(n+4+2*m/n)
        self.cs=(m+2)/(n+m+5)
        self.c1=2/((n+1.3)**2+m)
        self.cmu=min(1-self.c1,2*(m-2+1/m)/((n+2)**2+m))
        self.damping=1+2*max(0,np.sqrt((m-1)/(n+1))-1)+self.cs
        self.expected_norm=np.sqrt(n)*(1-1/(4*n)+1/(21*n*n))
        self.covariance=np.eye(n)
        self.eigenvectors=np.eye(n)
        self.scales=np.ones(n)
        self.path_sigma=np.zeros(n)
        self.path_covariance=np.zeros(n)
        self.rng=np.random.default_rng(seed)
        self.generation=0
        self.sigma_bound_hits=0
        self.eigenvalue_floors=0
        self.last_losses=None
        self._pending=None

    def ask(self):
        """Return one population; tell() must consume it before asking again."""
        if self._pending is not None:raise RuntimeError('Tell the pending population before calling ask again.')
        noise=self.rng.standard_normal((self.population_size,self.n))
        candidates=self.mean+self.sigma*((noise*self.scales)@self.eigenvectors.T)
        if not np.isfinite(candidates).all():raise FloatingPointError('Nonfinite CMA population.')
        self._pending=candidates.copy()
        return candidates

    def tell(self, candidates, losses):
        """Minimize losses for the original ask() population, without mutating it.

        Preserve the float64 candidates even when objective evaluation converts
        policy tensors to float32. Clipping or replacing candidates would change
        the distribution on which the covariance update relies and is rejected.
        """
        if self._pending is None:raise RuntimeError('Call ask before tell.')
        candidates=np.asarray(candidates,dtype=np.float64)
        losses=np.asarray(losses,dtype=np.float64)
        if candidates.shape!=(self.population_size,self.n) or not np.array_equal(candidates,self._pending):
            raise ValueError('Tell must receive the unchanged population returned by ask.')
        if losses.shape!=(self.population_size,) or not np.isfinite(losses).all():
            raise ValueError('Supply one finite loss per candidate.')
        # Stable sorting makes score ties reproducible; ask order is exchangeable.
        selected=np.argsort(losses,kind='stable')[:self.mu]
        steps=(candidates[selected]-self.mean)/self.sigma
        mean_step=self.weights@steps
        mean=self.mean+self.sigma*mean_step
        white_step=((mean_step@self.eigenvectors)/self.scales)@self.eigenvectors.T
        path_sigma=(1-self.cs)*self.path_sigma+np.sqrt(self.cs*(2-self.cs)*self.mu_eff)*white_step
        generation=self.generation+1
        corrected_norm=np.linalg.norm(path_sigma)/np.sqrt(1-(1-self.cs)**(2*generation))
        hsig=float(corrected_norm/self.expected_norm<1.4+2/(self.n+1))
        path_covariance=(1-self.cc)*self.path_covariance+hsig*np.sqrt(self.cc*(2-self.cc)*self.mu_eff)*mean_step
        retained=1-self.c1-self.cmu+self.c1*(1-hsig)*self.cc*(2-self.cc)
        covariance=retained*self.covariance+self.c1*np.outer(path_covariance,path_covariance)
        covariance+=self.cmu*(steps.T*self.weights)@steps
        covariance=(covariance+covariance.T)/2
        log_sigma=np.log(self.sigma)+(self.cs/self.damping)*(np.linalg.norm(path_sigma)/self.expected_norm-1)
        if not all(np.isfinite(x).all() for x in [mean,path_sigma,path_covariance,covariance]) or not np.isfinite(log_sigma):
            raise FloatingPointError('Nonfinite CMA update; previous generation retained.')
        values,vectors=np.linalg.eigh(covariance)
        if not np.isfinite(values).all() or values[-1]<=0 or values[0]<-1e-12*values[-1]:
            raise FloatingPointError('CMA covariance lost positive definiteness.')
        # Limit numerical condition number to 1e14; do not silently hide material
        # negative eigenvalues. This safeguard is separately counted in diagnostics.
        floor=max(1e-30,float(values[-1])*1e-14)
        floor_count=int((values<floor).sum())
        if floor_count:
            values=np.maximum(values,floor)
            covariance=(vectors*values)@vectors.T
            covariance=(covariance+covariance.T)/2
        lower,upper=np.log(self.sigma_min),np.log(self.sigma_max)
        sigma=float(np.clip(np.exp(np.clip(log_sigma,lower,upper)),self.sigma_min,self.sigma_max))
        self.mean,self.sigma=mean,sigma
        self.path_sigma,self.path_covariance=path_sigma,path_covariance
        self.covariance,self.eigenvectors,self.scales=covariance,vectors,np.sqrt(values)
        self.generation=generation
        self.sigma_bound_hits+=int(log_sigma<lower or log_sigma>upper)
        self.eigenvalue_floors+=floor_count
        self.last_losses=losses.copy()
        self._pending=None

    def diagnostics(self):
        return dict(generation=self.generation,dimension=self.n,population_size=self.population_size,
            sigma=self.sigma,mean_norm=float(np.linalg.norm(self.mean)),
            covariance_condition=float((self.scales[-1]/self.scales[0])**2),
            minimum_axis_std=float(self.sigma*self.scales[0]),maximum_axis_std=float(self.sigma*self.scales[-1]),
            sigma_bound_hits=self.sigma_bound_hits,eigenvalue_floors=self.eigenvalue_floors,
            loss_min=None if self.last_losses is None else float(self.last_losses.min()),
            loss_median=None if self.last_losses is None else float(np.median(self.last_losses)),
            unique_losses=None if self.last_losses is None else len(np.unique(self.last_losses)),
            pending_population=self._pending is not None)

    def state_dict(self):
        """Independent, JSON-serializable state for experiment audit/checkpointing."""
        return dict(version=1,method='positive-weight rank-one/rank-mu CMA-ES; eigendecomposition every generation',
            mean=self.mean.tolist(),sigma=self.sigma,sigma_min=self.sigma_min,sigma_max=self.sigma_max,
            population_size=self.population_size,weights=self.weights.tolist(),generation=self.generation,
            covariance=self.covariance.tolist(),eigenvectors=self.eigenvectors.tolist(),scales=self.scales.tolist(),
            path_sigma=self.path_sigma.tolist(),path_covariance=self.path_covariance.tolist(),
            sigma_bound_hits=self.sigma_bound_hits,eigenvalue_floors=self.eigenvalue_floors,
            last_losses=None if self.last_losses is None else self.last_losses.tolist(),
            pending_population=None if self._pending is None else self._pending.tolist(),
            rng_state=copy.deepcopy(self.rng.bit_generator.state))
