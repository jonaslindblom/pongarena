"""Depth versus width below 164 embedded scalars; independent frozen evaluation."""
from pathlib import Path
import sys,json,hashlib,subprocess,time
ROOT=Path(__file__).resolve().parents[3];OUT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'training/scripts'))
import numpy as np
import torch
from torch import nn
import onnx
from onnx import helper,numpy_helper
from policy import load_builtin,actions,OnnxPolicy
from pace_study import CONFIGS,PaceArena,make_policy,run_pair
from train_pace import broad_observations
from population import evaluate_population
from nano_cma import CMA
RULES=CONFIGS['pace13-v9-scaled']
FIELD=['robust-strong-v4','pacer-v4','vector-nano-v4','attack','defend','interceptor']
SHAPES=[[16],[8,8],[12,4],[8,6,4],[6,7,6],[8,5,4,4],[6,6,6,3]]
OLD=ROOT/'training/runs/nano163-warm-20261106/Nano-163-ReLU-CMA-candidate.onnx'
torch.set_num_threads(1)

def digest(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(name,obj):(OUT/name).write_text(json.dumps(obj,indent=2,allow_nan=False)+'\n')
def config():return json.loads((OUT/'protocol.json').read_text())
def stats(hidden):
 w=[6,*hidden,3];return dict(parameters=sum((a+1)*b for a,b in zip(w,w[1:])),macs=sum(a*b for a,b in zip(w,w[1:])))
def net(hidden,activation,seed=1):
 torch.manual_seed(seed);layers=[];widths=[6,*hidden,3]
 for i,(a,b) in enumerate(zip(widths,widths[1:])):
  layer=nn.Linear(a,b);nn.init.orthogonal_(layer.weight,gain=np.sqrt(2));nn.init.zeros_(layer.bias);layers.append(layer)
  if i<len(hidden):layers.append(nn.ReLU() if activation=='relu' else nn.Tanh())
 m=nn.Sequential(*layers)
 assert sum(p.numel() for p in m.parameters())==stats(hidden)['parameters']<=163
 return m

def load_file(path):
 graph=onnx.load(path).graph;weights={t.name:numpy_helper.to_array(t).copy() for t in graph.initializer};layers=[]
 for node in graph.node:
  if node.op_type=='Gemm':
   w=weights[node.input[1]];trans=next((a.i for a in node.attribute if a.name=='transB'),0);w=w if trans else w.T
   l=nn.Linear(w.shape[1],w.shape[0]);l.weight.data.copy_(torch.from_numpy(w));l.bias.data.copy_(torch.from_numpy(weights[node.input[2]]));layers.append(l)
  elif node.op_type in ['Relu','Tanh']:layers.append(nn.ReLU() if node.op_type=='Relu' else nn.Tanh())
  else:raise ValueError(node.op_type)
 return nn.Sequential(*layers).requires_grad_(False).eval()

def rivals(extra=False):
 r={n:make_policy(RULES,n) if n in ['attack','defend','interceptor'] else load_builtin(n).requires_grad_(False) for n in FIELD}
 if extra:r.update(old163=load_file(OLD),nano447=load_builtin('plain-nano-v4').requires_grad_(False))
 return r

def export(m,path,method):
 nodes=[];tensors=[];previous='observation'
 for i,l in enumerate(m):
  output='action_scores' if i==len(m)-1 else f'h{i}'
  if isinstance(l,nn.Linear):
   tensors.extend([numpy_helper.from_array(l.weight.detach().numpy(),f'w{i}'),numpy_helper.from_array(l.bias.detach().numpy(),f'b{i}')]);nodes.append(helper.make_node('Gemm',[previous,f'w{i}',f'b{i}'],[output],transB=1))
  else:nodes.append(helper.make_node('Relu' if isinstance(l,nn.ReLU) else 'Tanh',[previous],[output]))
  previous=output
 graph=helper.make_graph(nodes,'Plain dense depth study',[helper.make_tensor_value_info('observation',1,[1,6])],[helper.make_tensor_value_info('action_scores',1,[1,3])],tensors)
 model=helper.make_model(graph,opset_imports=[helper.make_opsetid('',18)],ir_version=10)
 widths=[6]+[l.out_features for l in m if isinstance(l,nn.Linear)]
 helper.set_model_props(model,{'rules':'pong-v4','architecture':'-'.join(map(str,widths)),'training':method,'parameters':str(sum(p.numel() for p in m.parameters()))})
 onnx.checker.check_model(model);onnx.save(model,path)

def field_score(row):return float(np.mean([row['opponents'][n] for n in FIELD]))

def prepare():
 if (OUT/'protocol.json').exists():raise FileExistsError('Already prepared')
 rng=np.random.default_rng(2026110623)
 cfg=dict(base_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),
  shapes=[dict(hidden=h,**stats(h)) for h in SHAPES],activations=['relu','tanh'],initialization_seeds=[9101,9109],teacher='plain-nano-v4',
  rounds=40,horizon=128,envs=256,optimizer_steps=128,batch=1024,eval_every=8,
  loss='Half cross-entropy action labels, half normalized teacher preference cross-entropy; identical shared observations/minibatches across arms.',
  compression='One additional ReLU 8-6-4 start: training-only neuron importance selection and ridge fitting to 447 intermediate activations on synthetic calibration observations, then same DAgger training.',
  training_interval=[0,1000000000],search_interval=[3700000000,3710000000],
  development_seeds=(rng.choice(10000000,12,replace=False)+3800000000).tolist(),
  selection_seeds=(rng.choice(10000000,64,replace=False)+3900000000).tolist(),
  confirmation_seeds=(rng.choice(10000000,256,replace=False)+4000000000).tolist(),verification_seeds=[4100000101,4100000109],
  field=FIELD,head_to_head=['old163','nano447'],cma=dict(generations=48,population=16,sigma=.06,screen_seeds=8,eval_every=8,starts='Best development student per hidden-layer count, including one-hidden control'),
  selection='Freeze every student best checkpoint and CMA checkpoint first. Preselect deepest-family primary: best six-opponent mean among 2-4 hidden-layer models with nonnegative direct old163 margin and no script >5pp worse than old163; otherwise best deep model, marked unqualified. Select best one-hidden control separately.',
  success='Paired-seed mean-field gain lower95%>0 versus old163, direct old163 margin lower95%>0, no script point-estimate regression >5pp. Assess 447 independently with same conditions; report all failures.',
  comparisons='Final deep primary, prior163, unchanged447, matched new one-hidden control. Same field excludes these compared models; direct matches reported separately. Each pairing uses both sides and five rallies. 10000 paired bootstrap samples across whole seeds.',
  limitations='Bounded architecture search; two shapes per deeper family and one shallow shape imply unequal architecture search opportunities. Fresh seed IDs can repeat physical openings. Training improvements do not by themselves establish a causal depth benefit.',
  references={str(OLD.relative_to(ROOT)):digest(OLD),**{f'public/models/{n}.onnx':digest(ROOT/f'public/models/{n}.onnx') for n in FIELD[:3]+['plain-nano-v4']}},
  sources={str(p.relative_to(ROOT)):digest(p) for p in [*sorted((ROOT/'training/scripts').glob('*.py')),OUT/'depth.py',OUT/'population.py',OUT/'nano_cma.py']})
 assert all(s['parameters']<=163 for s in cfg['shapes'])
 save('protocol.json',cfg)
 for p in sorted((ROOT/'training/scripts').glob('*.py')):
  d=OUT/'source'/p.name;d.parent.mkdir(exist_ok=True);d.write_bytes(p.read_bytes())
 print('Prepared',[(s['hidden'],s['parameters']) for s in cfg['shapes']],flush=True)

def verify():
 r=rivals();cfg=config();probes=broad_observations(np.random.default_rng(9100),1024);paths=[];checks=[]
 for shape in cfg['shapes']:
  h=shape['hidden']
  for a in cfg['activations']:
   models=[net(h,a,s) for s in [19,31]];rows,_=evaluate_population([m.state_dict() for m in models],a,cfg['verification_seeds'][:1],r)
   for i,m in enumerate(models):
    for n,p in r.items():assert abs(rows[i]['opponents'][n]-run_pair(RULES,m,p,cfg['verification_seeds'][:1])['summary']['point_margin'])<1e-12,(h,a,i,n)
   path=OUT/f'verify-{len(h)}-{"-".join(map(str,h))}-{a}.onnx';export(models[0],path,'Random verification fixture');paths.append(str(path))
   np.testing.assert_array_equal(actions(models[0],probes),OnnxPolicy(path)(probes));checks.append(dict(hidden=h,activation=a,distinct_members=2,opponents=len(r),native_torch_actions=len(probes)))
 subprocess.run(['node','--import','tsx','training/scripts/check_models.ts',*paths],cwd=ROOT,check=True,stdout=subprocess.DEVNULL)
 save('verification.json',dict(passed=True,checks=checks));print('Verified all shapes, activations, distinct population members, native actions, active graph contract.',flush=True)

def compressed_start(teacher):
 """Keep important teacher neurons; fit narrower dense layers on calibration data only."""
 x=torch.from_numpy(broad_observations(np.random.default_rng(9123),16384));m=net([8,6,4],'relu');old=x.clone();new=x.clone();details=[]
 with torch.no_grad():
  for i,l in enumerate([teacher[0],teacher[2],teacher[4],teacher[6]]):
   target=l(old)
   if i<3:
    activation=target.relu();importance=activation.square().mean(0).sqrt()*teacher[2*i+2].weight.square().sum(0).sqrt()
    ids=importance.topk([8,6,4][i]).indices.sort().values;target=target[:,ids];details.append(ids.tolist());old=activation
   z=torch.cat([new,torch.ones(len(new),1)],1).double();target=target.double()
   ridge=torch.eye(z.shape[1],dtype=torch.float64)*1e-3;ridge[-1,-1]=0
   fitted=torch.linalg.solve(z.T@z+ridge,z.T@target).float()
   m[2*i].weight.copy_(fitted[:-1].T);m[2*i].bias.copy_(fitted[-1]);new=m[2*i](new)
   if i<3:new=new.relu()
 assert all(torch.isfinite(p).all() for p in m.parameters())
 save('compressed-initialization.json',dict(hidden=[8,6,4],parameters=153,teacher_sha256=digest(ROOT/'public/models/plain-nano-v4.onnx'),calibration_observations=len(x),selected_original_neurons=details,training_only=True))
 return m

def train():
 cfg=config();r=rivals();teacher=load_builtin(cfg['teacher']).requires_grad_(False);models=[]
 if (OUT/'students').exists():raise FileExistsError('Already trained')
 (OUT/'students').mkdir()
 for shape in cfg['shapes']:
  for a in cfg['activations']:
   for seed in cfg['initialization_seeds']:
    h=shape['hidden'];name=f'{"x".join(map(str,h))}-{a}-{seed}'
    models.append(dict(name=name,hidden=h,activation=a,initialization='random',net=net(h,a,seed),best=-2))
 models.append(dict(name='8x6x4-relu-compressed',hidden=[8,6,4],activation='relu',initialization='compressed447',net=compressed_start(teacher),best=-2))
 for m in models:m['opt']=torch.optim.Adam(m['net'].parameters(),lr=.002)
 rng=np.random.default_rng(9111);env=PaceArena(cfg['envs'],RULES,seed=9111,loop_detection=False)
 model_ids=rng.integers(0,len(models),env.n);opponent_ids=rng.integers(0,len(r),env.n);replay=[];history=[]
 def check(iteration):
  for shape in cfg['shapes']:
   for a in cfg['activations']:
    group=[m for m in models if m['hidden']==shape['hidden'] and m['activation']==a]
    rows,_=evaluate_population([m['net'].state_dict() for m in group],a,cfg['development_seeds'],r)
    for m,row in zip(group,rows):
     score=field_score(row);history.append(dict(name=m['name'],round=iteration,**row))
     if score>m['best']:m['best']=score;torch.save(m['net'].state_dict(),OUT/'students'/f'{m["name"]}.pt')
     print('student',m['name'],'round',iteration,'score',round((score+1)*50,2),flush=True)
  save('training-metrics.json',history)
 check(0)
 for iteration in range(1,cfg['rounds']+1):
  observations=[]
  for _ in range(cfg['horizon']):
   x,y=env.obs(),env.obs(1);a=np.empty(env.n,int);b=np.empty(env.n,int);labels=actions(teacher,x)
   for i,m in enumerate(models):
    mask=model_ids==i
    if mask.any():a[mask]=np.where(rng.random(mask.sum())<max(.05,1-iteration/20),labels[mask],actions(m['net'],x[mask]))
   for i,p in enumerate(r.values()):
    mask=opponent_ids==i
    if mask.any():b[mask]=actions(p,y[mask]) if isinstance(p,nn.Module) else p(y[mask])
   observations.extend([x,y]);terminal,_=env.step(np.stack([a,b],1));ids=np.flatnonzero(terminal>=0);env.reset(ids)
   model_ids[ids]=rng.integers(0,len(models),len(ids));opponent_ids[ids]=rng.integers(0,len(r),len(ids))
  observations.append(broad_observations(rng,4096));replay.append(np.concatenate(observations));replay=replay[-4:];x=torch.from_numpy(np.concatenate(replay))
  with torch.no_grad():targets=torch.cat([teacher(part) for part in x.split(8192)])
  for m in models:m['opt'].param_groups[0]['lr']=.002*(.3+.7*(1-(iteration-1)/cfg['rounds']))
  losses=np.zeros(len(models))
  for _ in range(cfg['optimizer_steps']):
   ids=torch.from_numpy(rng.integers(0,len(x),cfg['batch']));target=targets[ids];soft=(target/target.std(-1,keepdim=True).clamp_min(.5)).softmax(-1)
   for i,m in enumerate(models):
    logits=m['net'](x[ids]);loss=.5*nn.functional.cross_entropy(logits,target.argmax(-1))+.5*(-soft*logits.log_softmax(-1)).sum(-1).mean()
    if not torch.isfinite(loss):raise FloatingPointError('Nonfinite training loss')
    m['opt'].zero_grad();loss.backward();nn.utils.clip_grad_norm_(m['net'].parameters(),1.,error_if_nonfinite=True);m['opt'].step();losses[i]+=float(loss.detach())
  print('round',iteration,'mean loss',round(float(losses.mean()/cfg['optimizer_steps']),4),flush=True)
  if iteration%cfg['eval_every']==0:check(iteration)
 save('students.json',[{k:v for k,v in m.items() if k in ['name','hidden','activation','initialization','best']} for m in models])

def search():
 cfg=config();c=cfg['cma'];r=rivals();students=json.loads((OUT/'students.json').read_text());pool=[]
 if (OUT/'search').exists():raise FileExistsError('Already searched')
 (OUT/'search').mkdir()
 for s in students:
  path='students/'+s['name']+'.pt';pool.append(dict(**s,path=path,sha256=digest(OUT/path),method='447 distillation; '+s['initialization']))
 starts=[max([m for m in students if len(m['hidden'])==depth],key=lambda m:m['best']) for depth in [1,2,3,4]];save('search-starts.json',starts)
 for index,spec in enumerate(starts):
  h,a=spec['hidden'],spec['activation'];m=net(h,a);m.load_state_dict(torch.load(OUT/'students'/f'{spec["name"]}.pt',weights_only=True));template=m.state_dict()
  origin=np.concatenate([v.numpy().ravel() for v in template.values()]).astype(float)
  scales=np.concatenate([np.full(v.numel(),max(float(template[k.replace('bias','weight')].square().mean().sqrt()),1/np.sqrt(template[k.replace('bias','weight')].shape[1]))) for k,v in template.items()])
  def decode(vector):
   physical=(origin+scales*vector).astype(np.float32);state={};offset=0
   assert np.isfinite(physical).all()
   for k,v in template.items():state[k]=torch.from_numpy(physical[offset:offset+v.numel()].reshape(v.shape).copy());offset+=v.numel()
   return state
  optimizer=CMA(np.zeros(len(origin)),c['sigma'],9201+index,c['population']);incumbent=np.zeros(len(origin));rng=np.random.default_rng(9211+index);history=[]
  for generation in range(1,c['generations']+1):
   proposals=optimizer.ask();vectors=[*proposals,optimizer.mean.copy(),incumbent.copy()];seeds=(rng.choice(10000000,c['screen_seeds'],replace=False)+3700000000).tolist()
   rows,_=evaluate_population([decode(v) for v in vectors],a,seeds,r);fitness=np.array([field_score(row) for row in rows]);optimizer.tell(proposals,-fitness[:c['population']]);chosen=len(vectors)-1
   if fitness.max()>fitness[chosen]+1e-12:chosen=int(fitness.argmax())
   incumbent=vectors[chosen].copy();row=dict(generation=generation,seeds=seeds,fitness=fitness.tolist(),chosen=chosen,optimizer=optimizer.diagnostics())
   if generation%c['eval_every']==0:
    dev,_=evaluate_population([decode(incumbent)],a,cfg['development_seeds'],r);row['development']=dev[0]
    name=f'depth{len(h)}-g{generation}';path='search/'+name+'.pt';torch.save(decode(incumbent),OUT/path)
    pool.append(dict(name=name,hidden=h,activation=a,path=path,sha256=digest(OUT/path),method='CMA refinement of '+spec['name']))
    print('CMA depth',len(h),'generation',generation,'dev score',round((field_score(dev[0])+1)*50,2),flush=True)
   else:print('CMA depth',len(h),'generation',generation,'training score',round((fitness[chosen]+1)*50,2),flush=True)
   history.append(row);save(f'search/depth{len(h)}-metrics.json',history)
  save(f'search/depth{len(h)}-optimizer.json',optimizer.state_dict())
 save('frozen-pool.json',pool)

def select():
 cfg=config();r=rivals(extra=True);pool=json.loads((OUT/'frozen-pool.json').read_text());results=[]
 for shape in cfg['shapes']:
  for a in cfg['activations']:
   group=[p for p in pool if p['hidden']==shape['hidden'] and p['activation']==a]
   for p in group:assert digest(OUT/p['path'])==p['sha256']
   rows,_=evaluate_population([torch.load(OUT/p['path'],weights_only=True) for p in group],a,cfg['selection_seeds'],r)
   for p,row in zip(group,rows):results.append(dict(**p,selection=row,field_margin=field_score(row)))
 baseline={n:run_pair(RULES,r['old163'],r[n],cfg['selection_seeds'])['summary']['point_margin'] for n in ['attack','defend','interceptor']}
 deep=[p for p in results if len(p['hidden'])>1]
 eligible=[p for p in deep if p['selection']['opponents']['old163']>=0 and all(p['selection']['opponents'][n]>=baseline[n]-.10 for n in baseline)]
 winner=max(eligible or deep,key=lambda p:p['field_margin']);shallow=max([p for p in results if len(p['hidden'])==1],key=lambda p:p['field_margin'])
 save('selection.json',dict(winner=winner,shallow=shallow,qualified=bool(eligible),old163_script_margins=baseline,candidates=results))
 frozen={}
 for name,spec in [('deep',winner),('shallow',shallow)]:
  m=net(spec['hidden'],spec['activation']);m.load_state_dict(torch.load(OUT/spec['path'],weights_only=True));path=OUT/f'{name}.onnx';export(m,path,spec['method'])
  frozen[name]=dict(**spec,onnx_sha256=digest(path),**stats(spec['hidden']))
 save('frozen-finalists.json',dict(finalists=frozen,qualified=bool(eligible)))
 print('FROZEN DEEP',winner['name'],winner['hidden'],winner['activation'],'score',round((winner['field_margin']+1)*50,2),'qualified',bool(eligible),flush=True)
 print('FROZEN SHALLOW',shallow['name'],'score',round((shallow['field_margin']+1)*50,2),flush=True)

def confirm():
 cfg=config();frozen=json.loads((OUT/'frozen-finalists.json').read_text());results={}
 assert not (OUT/'confirmation.json').exists()
 for name,spec in frozen['finalists'].items():assert digest(OUT/f'{name}.onnx')==spec['onnx_sha256']
 for path,want in cfg['references'].items():assert digest(ROOT/path)==want
 paths={'deep':OUT/'deep.onnx','old163':OLD,'nano447':ROOT/'public/models/plain-nano-v4.onnx','shallow':OUT/'shallow.onnx'}
 subprocess.run(['node','--import','tsx','training/scripts/check_models.ts',*map(str,paths.values())],cwd=ROOT,check=True,stdout=subprocess.DEVNULL)
 native={n:make_policy(RULES,n) if n in ['attack','defend','interceptor'] else OnnxPolicy(ROOT/f'public/models/{n}.onnx') for n in FIELD}
 for name,path in paths.items():
  targets=dict(native);results[name]={}
  if name=='deep':targets.update({n:OnnxPolicy(paths[n]) for n in ['old163','nano447','shallow']})
  for opponent,policy in targets.items():
   row=run_pair(RULES,OnnxPolicy(path),policy,cfg['confirmation_seeds'])['summary'];results[name][opponent]=row
   print('FINAL',name,opponent,'score',round(row['score_rate']*100,2),'games',row['match_wins'],row['match_losses'],row['match_draws'],flush=True);save('confirmation-progress.json',results)
 values={n:np.array([[p['paired_point_margin']/20+.5 for p in results[n][o]['per_seed']] for o in FIELD]).mean(0) for n in results}
 rng=np.random.default_rng(9301);ix=rng.integers(0,len(values['deep']),(10000,len(values['deep'])));summary=dict(scores={n:float(v.mean()) for n,v in values.items()},comparisons={})
 for n in ['old163','nano447','shallow']:
  delta=values['deep']-values[n];ci=np.quantile(delta[ix].mean(1),[.025,.975]).tolist();direct=results['deep'][n]['point_margin_ci95']
  script_deltas={o:results['deep'][o]['score_rate']-results[n][o]['score_rate'] for o in ['attack','defend','interceptor']}
  summary['comparisons'][n]=dict(gain=float(delta.mean()),ci95=ci,direct_margin_ci95=direct,script_deltas=script_deltas,success=ci[0]>0 and direct[0]>0 and min(script_deltas.values())>=-.05)
 save('confirmation.json',dict(frozen=frozen,summary=summary,results=results));print('CONFIRMED',summary,flush=True)

if __name__=='__main__':
 for stage in sys.argv[1:]:print('STAGE',stage,flush=True);globals()[stage]()
