"""Frozen trained Nano versus handwritten Quill Plus; no training or selection."""
from dataclasses import asdict
from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'training/scripts'))
import numpy as np
from pace_study import CONFIGS, make_policy, run_pair
from policy import OnnxPolicy

RULES = CONFIGS['pace13-v9-scaled']
FIELD = ['robust-strong-v4', 'pacer-v4', 'vector-nano-v4', 'attack', 'defend', 'interceptor']
MODELS = {
    'trained': ROOT / 'training/runs/nano163-refine-20261106/Nano-163-Refined-Tanh.onnx',
    'quill_plus': ROOT / 'public/models/quill-plus-v4.onnx',
}
EXPECTED = {
    'trained': '3772611174d50c181668ed5f4984b65d6e8fbaad6b438a942941ad9901497633',
    'quill_plus': 'd2a4f54c292b1925b8d99c82e86801f987f22566a4e377233230b3b1c5ca5273',
}


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(name, value):
    path = OUT / name
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, allow_nan=False) + '\n')


def prepare():
    assert not (OUT / 'protocol.json').exists(), 'Preserve the frozen protocol.'
    models = dict(MODELS)
    models.update({name: ROOT / f'public/models/{name}.onnx' for name in FIELD[:3]})
    identities = {}
    for name, path in models.items():
        sha = digest(path)
        if name in EXPECTED:
            assert sha == EXPECTED[name], name
        frozen = OUT / 'models' / f'{name}.onnx'
        frozen.parent.mkdir(exist_ok=True)
        frozen.write_bytes(path.read_bytes())
        identities[name] = dict(source=str(path.relative_to(ROOT)), frozen=str(frozen.relative_to(OUT)), sha256=sha)
    validator = subprocess.check_output(
        ['node', '--import', 'tsx', 'training/scripts/check_models.ts',
         *[str(OUT / spec['frozen']) for spec in identities.values()]], cwd=ROOT, text=True)
    checks = [json.loads(line) for line in validator.splitlines()]
    for name, check in zip(identities, checks):
        assert check['sha256'] == identities[name]['sha256']
        if name in EXPECTED:
            assert check['params'] == 163
        identities[name]['validation'] = check
    sources = [Path(__file__), *sorted((ROOT / 'training/scripts').glob('*.py'))]
    for source in sources:
        snapshot = OUT / 'source' / source.name
        snapshot.parent.mkdir(exist_ok=True)
        snapshot.write_bytes(source.read_bytes())
    save('protocol.json', dict(
        registered_at_utc=datetime.now(timezone.utc).isoformat(),
        commit=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(),
        models=identities, sources={str(p.relative_to(ROOT)): digest(p) for p in sources},
        rules=asdict(RULES), field=FIELD,
        seeds=(np.random.default_rng(2026110641).choice(1000000, 256, replace=False) + 4280000000).tolist(),
        seed_range=[4280000000, 4281000000], bootstrap_samples=10000, bootstrap_seed=9641,
        procedure='Fixed two models; direct matchup plus both against the same six opponents. Native ONNX, deterministic argmax, both sides, five rallies per game; no training or checkpoint selection.',
        primary='Direct trained-model rally score versus 50%; equal-weight common-field score difference Quill Plus minus trained model. Paired whole-seed 95% bootstrap intervals.',
        limits='Fixed opponent field; opponent-specific differences are descriptive. Distinct seed IDs can repeat physical openings. Both designs have been informed by earlier games. This measures retained model strength, not a causal comparison of architecture or training methods.',
    ))
    print('Prepared: two frozen 163-parameter models, 256 paired seeds, 13 matchups.', flush=True)


def verify(cfg):
    for name, spec in cfg['models'].items():
        assert digest(OUT / spec['frozen']) == spec['sha256'], name
        assert digest(ROOT / spec['source']) == spec['sha256'], name
    for path, sha in cfg['sources'].items():
        assert digest(ROOT / path) == sha, path


def scores(row):
    return np.array([r['paired_point_margin'] / 20 + .5 for r in row['per_seed']])


def run():
    cfg = json.loads((OUT / 'protocol.json').read_text())
    assert not (OUT / 'comparison.json').exists(), 'Do not overwrite completed comparisons.'
    verify(cfg)
    policies = {n: OnnxPolicy(OUT / s['frozen']) for n, s in cfg['models'].items()}
    policies.update({n: make_policy(RULES, n) for n in FIELD[3:]})
    matchups = [('trained', 'quill_plus')] + [(name, rival) for name in MODELS for rival in FIELD]
    rows = {}
    for name, rival in matchups:
        key = f'{name}-vs-{rival}'
        result = run_pair(RULES, policies[name], policies[rival], cfg['seeds'])
        save(f'matches/{key}.json', result)
        rows[key] = result['summary']
        r = result['summary']
        print(key, f"score {r['score_rate'] * 100:.3f}%", 'games', r['match_wins'], r['match_losses'], r['match_draws'], flush=True)
    verify(cfg)
    ix = np.random.default_rng(cfg['bootstrap_seed']).integers(0, len(cfg['seeds']), (cfg['bootstrap_samples'], len(cfg['seeds'])))
    interval = lambda v: np.quantile(v[ix].mean(1), [.025, .975]).tolist()
    field = {name: np.stack([scores(rows[f'{name}-vs-{r}']) for r in FIELD]).mean(0) for name in MODELS}
    delta = field['quill_plus'] - field['trained']
    direct = scores(rows['trained-vs-quill_plus'])
    direct_ci = interval(direct)
    summary = dict(
        field_scores={name: dict(score=float(v.mean()), ci95=interval(v)) for name, v in field.items()},
        quill_plus_field_gain=dict(score=float(delta.mean()), ci95=interval(delta)),
        direct_trained_score=dict(score=float(direct.mean()), ci95=direct_ci,
            winner='trained' if direct_ci[0] > .5 else 'quill_plus' if direct_ci[1] < .5 else 'inconclusive'),
        per_opponent={r: {name: rows[f'{name}-vs-{r}']['score_rate'] for name in MODELS} for r in FIELD},
        matchups=len(rows), games=len(rows) * len(cfg['seeds']) * 2, rallies=len(rows) * len(cfg['seeds']) * 10,
    )
    save('comparison.json', dict(protocol_sha256=digest(OUT / 'protocol.json'), summary=summary, results=rows,
        match_hashes={p.name: digest(p) for p in sorted((OUT / 'matches').glob('*.json'))}))
    print('CONFIRMED', json.dumps(summary), flush=True)


def report():
    cfg = json.loads((OUT / 'protocol.json').read_text())
    data = json.loads((OUT / 'comparison.json').read_text())
    s = data['summary']; direct = data['results']['trained-vs-quill_plus']
    lines = ['TRAINED NANO 163 VERSUS QUILL PLUS', '',
        'Trained: 6->16->3 Tanh; 163 parameters; 144 MACs; distillation and evolutionary refinement.',
        'Quill Plus: 6->12->4->3->3 ReLU; 163 parameters; 141 MACs; handwritten weights informed by development games.',
        f"Commit: {cfg['commit']}",
        'Frozen models; 256 fresh paired seeds; both sides; five rallies per game; native ONNX inference.',
        'No training or checkpoint selection. All confidence intervals below use 10,000 whole-seed bootstrap samples.',
        '', 'Head-to-head, from trained model perspective:',
        f"Games W/L/D: {direct['match_wins']}/{direct['match_losses']}/{direct['match_draws']}.",
        f"Rallies W/L/D: {direct['wins']}/{direct['losses']}/{direct['draws']}.",
        f"Trained rally score: {s['direct_trained_score']['score'] * 100:.2f}%; 95% CI {np.array(s['direct_trained_score']['ci95']) * 100}.",
        '', 'Common-field rally scores (draws count as half):', 'Opponent | Trained Nano 163 | Quill Plus']
    for rival, row in s['per_opponent'].items():
        lines.append(f"{rival} | {row['trained'] * 100:.2f}% | {row['quill_plus'] * 100:.2f}%")
    lines.append('Mean | ' + ' | '.join(f"{s['field_scores'][n]['score'] * 100:.2f}%" for n in MODELS))
    gain = s['quill_plus_field_gain']
    lines += [f"Quill Plus field gain: {gain['score'] * 100:+.2f} percentage points; 95% CI {np.array(gain['ci95']) * 100}.", '',
        f"Total: {s['games']:,} games / {s['rallies']:,} rallies across {s['matchups']} matchups.",
        'Field: Robust Strong, Pacer, Vector Nano, Attacker, Defender, Interceptor. Neither compared model is included in the common field.',
        'Scores from the earlier Quill report used a different ten-opponent field and cannot be compared directly with these six-opponent averages.',
        cfg['limits'],
        'Raw evaluator rows retain their original 2,000-sample intervals. Comparison summary/report uses the registered 10,000 samples.',
        'No app, catalog or model changes. Protocol, frozen weights, source snapshots and complete match records retained alongside this report.']
    (OUT / 'RESULTS.txt').write_text('\n'.join(lines) + '\n')
    print('\n'.join(lines[7:23]))


if __name__ == '__main__':
    for stage in sys.argv[1:]:
        globals()[stage]()
