Quill Nano v4 evidence (2026-11-06)

The candidate was frozen before evaluating the 128 held-out seeds. All
performance outcomes are fixed-model measurements, not training data.

In a checkout of the accompanying repository with its documented dependencies:
  python training/scripts/quill_dense_v4.py --out /tmp/new-quill.onnx
  node --import tsx training/scripts/check_models.ts /tmp/new-quill.onnx

Reproduce the evaluation using a NEW output path:
  python training/scripts/evaluate_current.py /tmp/new-quill.onnx --seeds-file training/runs/handwritten-163/heldout-seeds.json --output /tmp/quill-results.json --opponents tracker pacer-v4 plain-nano-v4 vector-nano-v4 prism-small-v4 robust-strong-v4 apprentice-v4 attack defend interceptor

Verify the native recordings with ONNX Runtime Web and live TypeScript physics:
  node --import tsx training/runs/handwritten-163/verify_wasm.ts

This archive retains source snapshots, all evaluated model bytes, development
proposals, seeds, results, probes and complete replays. The Python/native probe
producer is verify_native.py. Its outputs are already included. requirements-lock.txt
and package-lock.json record dependencies. No optimizer or fit was run.

The initial short-forecast intercept bug's overwritten raw result file is not
retained. Corrected development proposals and their results are retained; see
development-history.json. Final seed lists are consumed: do not tune on them.
