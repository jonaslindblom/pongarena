"""Native-runtime evidence; no candidate selection or weight changes."""
import hashlib, importlib.util, json, sys
from pathlib import Path
import numpy as np
import onnxruntime as ort
sys.path.insert(0,str(Path('training/scripts').resolve()))
from quill_dense_v4 import export
P=Path('training/runs/handwritten-163')
export(P/'reproduced.onnx')
assert (P/'reproduced.onnx').read_bytes()==Path('public/models/quill-nano-v4.onnx').read_bytes()
opts=ort.SessionOptions();opts.intra_op_num_threads=1;opts.inter_op_num_threads=1
sessions={name:ort.InferenceSession(str(Path('public/models')/(name+'.onnx')),sess_options=opts,providers=['CPUExecutionProvider']) for name in ['quill-nano-v4','pacer-v4','robust-strong-v4']}
def scores(name,obs):
 return sessions[name].run(None,{'observation':np.asarray(obs,dtype=np.float32)[None]})[0][0].tolist()
spec=importlib.util.spec_from_file_location('classic','training/v4/reference.py');ref=importlib.util.module_from_spec(spec);spec.loader.exec_module(ref)
rng=np.random.default_rng(16320261106)
probes=[]
for _ in range(4096):
 f=dict(x=int(rng.integers(15,346)),y=int(rng.integers(4,157)),vx=int(rng.choice([-13,-12,-9,-5,5,9,12,13])),vy=int(rng.integers(-9,10)),paddles=rng.integers(15,146,2).tolist())
 obs=ref.observation(f,0);probes.append(dict(observation=obs,scores=scores('quill-nano-v4',obs)))
# Probe the stay/move threshold on both sides, including float32 neighbours.
for other in [79,80]:
 target=80+(19/312*80)*(1 if other>=80 else -1)
 for delta in [-1.1001,-1.1,-1.0999,0,1.0999,1.1,1.1001]:
  f=dict(x=16,y=80,vx=-13,vy=0,paddles=[target+delta,other])
  obs=ref.observation(f,0);probes.append(dict(observation=obs,scores=scores('quill-nano-v4',obs)))
(P/'native-probes.json').write_text(json.dumps(probes,separators=(',',':')))
seeds=json.loads((P/'heldout-seeds.json').read_text())[:2]
matches=[]
for opponent in ['pacer-v4','robust-strong-v4']:
 for side in [0,1]:
  for seed in seeds:
   names=[opponent,opponent];names[side]='quill-nano-v4'
   frame=ref.serve(seed);loops=ref.LoopDetector();steps=[]
   while not ref.ended_match(frame):
    if ref.ended_rally(frame):
     frame=ref.serve(seed,frame);ss=None
    else:
     ss=[scores(name,ref.observation(frame,s)) for s,name in enumerate(names)]
     frame=ref.advance(frame,ss,loops)
    steps.append(dict(scores=ss,state=frame))
   matches.append(dict(seed=seed,models=names,steps=steps))
(P/'native-replays.json').write_text(json.dumps(matches,separators=(',',':')))
print(json.dumps(dict(reproduction='byte-identical',probes=len(probes),matches=len(matches),frames=sum(len(m['steps']) for m in matches))))
