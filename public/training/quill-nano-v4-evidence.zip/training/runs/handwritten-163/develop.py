"""Explicit manual hypotheses. No fitting, optimizers, or automated weight search."""
import sys, json
from pathlib import Path
import numpy as np
import torch
from torch import nn
sys.path.insert(0,str(Path('training/scripts').resolve()))
from pace_study import CONFIGS, run_pair, make_policy
from policy import load_builtin
from analytic_dense_v4 import export
ROOT=Path('training/runs/handwritten-163')
torch.set_num_threads(1)

def net(arrays):
    layers=[]
    for i,(w,b) in enumerate(arrays):
        layer=nn.Linear(w.shape[1],len(b))
        with torch.no_grad():
            layer.weight.copy_(torch.tensor(w,dtype=torch.float32))
            layer.bias.copy_(torch.tensor(b,dtype=torch.float32))
        layers.append(layer)
        if i<len(arrays)-1: layers.append(nn.ReLU())
    result=nn.Sequential(*layers).eval()
    assert sum(p.numel() for p in result.parameters())==163
    return result

def short_forecast():
    # Fixed four-tick lookahead; incoming reflection and opponent-side aim.
    w=np.zeros((16,6));b=np.zeros(16);c=np.zeros(16)
    for i,(k,a) in enumerate(zip([-4.75,-2.85,-.95,.95,2.85],[1,-2,2,-2,2])):
        w[i,1]=1; w[i,3]=.3; w[i,2]=-20; b[i]=-k-20*13/6
        # Gate through velocity sign without shifting the forecast: two hinges
        # per reflection term, subtracting identical incoming velocity offsets.
    # A simple ungated baseline uses just reflection and linear aiming.
    for i,(k,a) in enumerate(zip([-4.75,-2.85,-.95,.95,2.85],[1,-2,2,-2,2])):
        w[i]=[0,1,0,.3,0,0];b[i]=-k;c[i]=a*83/78
    w[5,4]=1;b[5]=1;c[5]=-1
    w[6,5]=160;b[6]=2;c[6]=19/312
    w[7,5]=160;b[7]=0;c[7]=-19/312
    return net([(w,b),(np.stack([-c,np.zeros(16),c]),np.array([.95*83/78+19/312-1,1.1/80,1-.95*83/78-19/312]))])

def min_flight():
    # Product approximation: min(distance, |vy|), exact at their crossing.
    w=np.zeros((8,6));b=np.zeros(8)
    for i,(sx,sv) in enumerate([(1,1),(-1,-1),(1,-1),(-1,1)]):
        w[i,0]=sx;w[i,3]=sv*.5;b[i]=sx*11/12
    w[4,1]=1;w[4,3]=6*.5/80;b[4]=2
    w[5,4]=1;b[5]=1
    w[6,2]=1
    w[7,5]=1;b[7]=1
    z=np.array([1,1,-1,-1,0,0,0,0])*6*180/(13*80)/2
    z[4]=1
    v=np.zeros((6,8));d=np.zeros(6)
    for i,k in enumerate([-2.85,-.95,.95]):
        v[i]=z;v[i,6]=-20;d[i]=-2-k
    v[3,5]=1
    v[4,6]=-2;d[4]=1
    v[5,7]=1
    u=np.zeros((5,6));e=np.zeros(5)
    # Folded forecast plus shifted paddle, incoming cue and opponent plateau.
    u[0,:3]=[-1,2,-2];u[0,4]=.95;e[0]=1
    u[1,3]=1
    u[2,4]=1
    u[3,5]=160;e[3]=-158
    u[4,5]=160;e[4]=-160
    co=np.array([83/78,-1,-19/312,19/312,-19/312])
    return net([(w,b),(v,d),(u,e),(np.stack([-co,np.zeros(5),co]),np.array([83/78-1,1.1/80,1-83/78]))])

def square_flight(refined=False):
    w=np.zeros((12,6));b=np.zeros(12)
    knots=np.array([-1,0,1,2])*(2/3 if refined else 1)
    for j,sign in enumerate([1,-1]):
        for i,k in enumerate(knots):
            w[4*j+i,0]=1;w[4*j+i,3]=sign*2/3;b[4*j+i]=11/12-k
    w[8,1]=1;w[8,3]=6*.5/80;b[8]=3
    w[9,4]=1;b[9]=1
    w[10,2]=1
    w[11,5]=160;b[11]=2
    z=np.zeros(12);z[:4]=np.array([-1,2,2,2])*6*180/(13*80)/(4*2/3);z[4:8]=-z[:4];z[8]=1
    if refined:
        # Add the linear tail instead of wasting the first hinge as a baseline.
        # Four knots now describe five square segments, including negative u.
        a=2/3
        z[:4]=2*a*6*180/(13*80)/(4*2/3);z[4:8]=-z[:4]
        w[8,3]=6*(8/13)/80-3*a*2*(2/3)*6*180/(13*80)/(4*2/3)
    v=np.zeros((4,12));d=np.zeros(4)
    v[0]=z;v[0,10]=-20;d[0]=1
    v[1,9]=1;v[1,11]=-19/312;d[1]=10
    v[2,10]=-2;d[2]=1
    v[3,11]=1;d[3]=-2
    u=np.zeros((3,4));e=np.zeros(3)
    A=83/78;C=19/312
    u[0]=[A,-1,-4*A,-C];e[0]=15
    u[1]=[1,0,-4,0];e[1]=-.95
    u[2]=[-1,0,4,0];e[2]=-.95
    co=np.array([1,-2*A,2*A])
    return net([(w,b),(v,d),(u,e),(np.stack([-co,np.zeros(3),co]),np.array([4+C,1.1/80,-4-C]))])

def safe_flight():
    actor=square_flight(True)
    with torch.no_grad():
        actor[0].bias[8]+=1
        actor[2].bias[0]-=1
        actor[4].bias[0]+=2
        actor[6].bias[0]+=2
        actor[6].bias[2]-=2
    return actor

models={'short-forecast' :short_forecast(),'min-flight':min_flight(),'square-flight':square_flight(),'five-segments':square_flight(True),'five-safe':safe_flight()}
if __name__=='__main__':
    seeds=json.loads((ROOT/'development-seeds.json').read_text())
    for name in sys.argv[1:] or models:
        actor=models[name]
        export(actor,ROOT/(name+'.onnx'))
        result={}
        for opponent in ['tracker','pacer-v4','vector-nano-v4','plain-nano-v4','attack','defend']:
            rival=make_policy(CONFIGS['pace13-v9-scaled'],opponent) if opponent in ['attack','defend'] else load_builtin(opponent)
            r=run_pair(CONFIGS['pace13-v9-scaled'],actor,rival,seeds)
            result[opponent]=r
            s=r['summary'];print(name,opponent,{k:s[k] for k in ['wins','losses','draws','paired_match_wins','paired_match_losses']},flush=True)
        (ROOT/(name+'-development.json')).write_text(json.dumps(result))
