Quill Plus v4 evidence (2026-11-06)

Four handwritten changes; same 163-parameter/141-MAC dense network.
No training or automated fitting. The original Quill is preserved.

Ten manual revisions and the baseline were compared on 64 development seeds.
The speed-recovery proposal was frozen before opening the separate 128-seed
confirmation set. freeze.json identifies the candidate, source and seeds,
and records the predeclared ten-opponent mean-score promotion criterion.
comparison.json includes the matched gain and all matchup tradeoffs.

In a checkout of the accompanying repository with documented dependencies:
  python training/scripts/quill_plus_dense_v4.py --out /tmp/new-quill-plus.onnx
  node --import tsx training/scripts/check_models.ts /tmp/new-quill-plus.onnx
  python training/runs/quill-refinement/compare.py
  node --import tsx training/runs/quill-refinement/verify_wasm.ts

The archive contains frozen source snapshots, evaluated model files, all manual
proposals, seeds, native results, probes and complete replays. evaluate_current.py
reproduces either confirmation with heldout-seeds.json and a fresh output path.
Use the ten field opponents recorded in freeze.json; add quill-nano-v4 for the
separate Plus/original matchup. Raw results already exist and must not be silently
overwritten. requirements-lock.txt and package-lock.json identify dependencies.

The constructor docstring was clarified after freezing to explicitly distinguish
manual hypotheses from automated weight search. freeze.json preserves the original
source hash and snapshot plus this documentation-only change. Executable code and
all model bytes are unchanged. Final seeds are consumed; never tune on them.
