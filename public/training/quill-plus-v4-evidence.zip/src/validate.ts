import pb from 'onnx-proto'
import type { onnx } from 'onnx-proto'

export const MAX_BYTES = 256 * 1024
export const MAX_MACS = 65536
export const MAX_DENSE_HIDDEN_LAYERS = 4
export class ArchivedModelError extends Error {
  constructor() {
    super('This model uses the archived Burst contract. Import a Classic v4 model with six inputs and three action scores: up, stay, down.')
    this.name = 'ArchivedModelError'
  }
}

export class DenseModelError extends Error {
  constructor(reason: string) {
    super('Use a plain dense network with fixed weights and biases: ' + reason)
    this.name = 'DenseModelError'
  }
}

export function validateArenaModel(bytes: Uint8Array) {
  const stats = validateModel(bytes)
  if (stats.inputSize !== 6 || stats.outputSize !== 3) throw new ArchivedModelError()
  validateDenseGraph(pb.onnx.ModelProto.decode(bytes).graph!)
  return stats
}

function denseCheck(ok: unknown, message: string): asserts ok {
  if (!ok) throw new DenseModelError(message)
}

function validateDenseGraph(graph: onnx.IGraphProto) {
  const nodes = graph.node ?? []
  denseCheck(nodes.length % 2 === 1 && nodes.length <= 2 * MAX_DENSE_HIDDEN_LAYERS + 1,
    `use zero to ${MAX_DENSE_HIDDEN_LAYERS} hidden layers, each followed by the same ReLU or Tanh activation.`)
  const initializers = new Map((graph.initializer ?? []).map((tensor) => [tensor.name, tensor]))
  const used = new Set<string>()
  let previous = 'observation', width = 6, activation: string | undefined
  for (const [index, node] of nodes.entries()) {
    const inputs = node.input ?? []
    denseCheck(inputs[0] === previous, 'layers must form one sequential chain from observation to action_scores.')
    if (index % 2 === 1) {
      denseCheck((node.opType === 'Relu' || node.opType === 'Tanh') && inputs.length === 1 &&
        !node.attribute?.length, 'hidden layers require an unmodified ReLU or Tanh activation.')
      activation ??= node.opType
      denseCheck(node.opType === activation, 'use the same activation throughout the hidden layers.')
    } else {
      denseCheck(node.opType === 'Gemm' && inputs.length === 3,
        'each dense layer must be a Gemm of its input, an embedded weight matrix, and an embedded bias vector.')
      const attributes = new Map<string, onnx.IAttributeProto>()
      for (const attr of node.attribute ?? []) {
        const name = attr.name ?? ''
        denseCheck(!attributes.has(name), 'Gemm attributes must not repeat.')
        denseCheck(
          ((name === 'transA' || name === 'transB') && attr.type === 2 &&
            (name === 'transA' ? Number(attr.i) === 0 : [0, 1].includes(Number(attr.i)))) ||
          ((name === 'alpha' || name === 'beta') && attr.type === 1 && attr.f === 1),
          'Gemm permits only transB=0/1, transA=0, and unit alpha/beta scaling.',
        )
        denseCheck(!attr.g && !attr.graphs?.length && !attr.t && !attr.tensors?.length &&
          !attr.floats?.length && !attr.ints?.length && !attr.s?.length && !attr.strings?.length,
          'Gemm attributes cannot contain additional tensors or subgraphs.')
        attributes.set(name, attr)
      }
      const weight = initializers.get(inputs[1]), bias = initializers.get(inputs[2])
      denseCheck(weight && bias && !used.has(inputs[1]) && !used.has(inputs[2]) &&
        inputs[1] !== inputs[2], 'each layer must own distinct embedded weights and biases, used once.')
      const dims = (weight.dims ?? []).map(Number)
      const transposed = Number(attributes.get('transB')?.i ?? 0) === 1
      const inputWidth = dims[transposed ? 1 : 0], outputWidth = dims[transposed ? 0 : 1]
      denseCheck(dims.length === 2 && inputWidth === width && bias.dims?.length === 1 &&
        Number(bias.dims[0]) === outputWidth,
        'weights must be dense matrices and biases must be one vector matching the layer width.')
      for (const tensor of [weight, bias]) {
        const count = product((tensor.dims ?? []).map(Number))
        const raw = tensor.rawData, floats = tensor.floatData
        denseCheck(Boolean(raw?.length) !== Boolean(floats?.length),
          'store each parameter tensor once as float32 values.')
        denseCheck(!tensor.doubleData?.length && !tensor.int32Data?.length && !tensor.int64Data?.length &&
          !tensor.uint64Data?.length && !tensor.stringData?.length && !tensor.segment,
          'parameter tensors may contain only their embedded float32 values.')
        if (raw?.length) {
          const view = new DataView(raw.buffer, raw.byteOffset, raw.byteLength)
          for (let i = 0; i < count; i++)
            denseCheck(Number.isFinite(view.getFloat32(i * 4, true)), 'every weight and bias must be finite.')
        } else {
          denseCheck(floats?.every(Number.isFinite), 'every weight and bias must be finite.')
        }
      }
      used.add(inputs[1])
      used.add(inputs[2])
      width = outputWidth
    }
    previous = node.output![0]
    denseCheck(index === nodes.length - 1 || previous !== 'action_scores',
      'only the final linear layer may produce action_scores.')
  }
  denseCheck(previous === 'action_scores' && width === 3,
    'the final layer must directly produce three linear action scores.')
  denseCheck(used.size === initializers.size, 'unused constants and parameter tensors are not permitted.')
}

type Shape = number[]
const product = (dims: Shape) => dims.reduce((a, b) => a * b, 1)
function check(ok: unknown, message: string): asserts ok {
  if (!ok) throw new Error(message)
}
function broadcast(a: Shape, b: Shape): Shape {
  const rank = Math.max(a.length, b.length)
  return Array.from({ length: rank }, (_, i) => {
    const x = a[i - rank + a.length] ?? 1,
      y = b[i - rank + b.length] ?? 1
    check(x === y || x === 1 || y === 1, 'Incompatible tensor shapes.')
    return Math.max(x, y)
  })
}
function checkPort(list: onnx.IValueInfoProto[], name: string, size: number) {
  const p = list[0],
    t = p?.type?.tensorType
  const dims = t?.shape?.dim?.map((d) => Number(d.dimValue))
  check(
    list.length === 1 && p.name === name && t?.elemType === 1 && dims?.join() === '1,' + size,
    'Expected ' + name + ' as float32[1, ' + size + '].',
  )
}

// Inspect immutable historical graphs. Active uploads must use validateArenaModel.
export function validateModel(bytes: Uint8Array) {
  check(bytes.length > 0 && bytes.length <= MAX_BYTES, 'Choose an ONNX file up to 256 KiB.')
  let model: onnx.ModelProto
  try {
    model = pb.onnx.ModelProto.decode(bytes)
  } catch {
    throw new Error('This file is not a readable ONNX model.')
  }
  const g = model.graph
  check(
    g &&
      model.opsetImport.length === 1 &&
      !model.opsetImport[0].domain &&
      Number(model.opsetImport[0].version) === 18,
    'Use standard ONNX opset 18.',
  )
  check(
    !model.functions.length && !model.trainingInfo.length && !g.sparseInitializer?.length,
    'Use a self-contained inference graph.',
  )
  const inputSize = Number(g.input?.[0]?.type?.tensorType?.shape?.dim?.[1]?.dimValue)
  check(inputSize === 6 || inputSize === 8, 'Use six inputs for Classic v4 or eight for Burst preview.')
  const outputSize = inputSize === 8 ? 5 : 3
  checkPort(g.input ?? [], 'observation', inputSize)
  checkPort(g.output ?? [], 'action_scores', outputSize)
  const shapes = new Map<string, Shape>([['observation', [1, inputSize]]])
  let params = 0,
    macs = 0,
    elements = 0
  for (const p of g.initializer ?? []) {
    const dims = (p.dims ?? []).map(Number),
      n = product(dims)
    check(
      p.name &&
        !shapes.has(p.name) &&
        p.dataType === 1 &&
        !p.dataLocation &&
        !p.externalData?.length &&
        dims.length <= 8 &&
        dims.every((d) => Number.isSafeInteger(d) && d > 0) &&
        n <= 65536,
      'Weights must be embedded float32 tensors of bounded size.',
    )
    check(
      p.rawData?.length === n * 4 || p.floatData?.length === n,
      'A weight tensor has missing data.',
    )
    shapes.set(p.name, dims)
    params += n
  }
  const nodes = g.node ?? []
  const operations: { op: string; inputs: string[]; output: string; shape: Shape }[] = []
  const widths = [inputSize]
  let sequential = true
  let previous = 'observation'
  const constants = new Set((g.initializer ?? []).map((p) => p.name))
  check(nodes.length <= 256, 'Limit the graph to 256 operators.')
  for (const node of nodes) {
    const op = node.opType
    check(
      !node.domain && op && ['Gemm', 'MatMul', 'Add', 'Relu', 'Tanh'].includes(op),
      'Unsupported operator: ' + op,
    )
    const attrs = new Map((node.attribute ?? []).map((a) => [a.name, a]))
    for (const [name, attr] of attrs) {
      check(
        op === 'Gemm' &&
          ['transA', 'transB', 'alpha', 'beta'].includes(name ?? '') &&
          (attr.type === 1 || attr.type === 2),
        'Unsupported operator attribute.',
      )
    }
    const inputs = (node.input ?? []).map((name) => {
      const shape = shapes.get(name)
      check(shape, 'Each node must use an earlier result or embedded weights.')
      return shape
    })
    const [a, b, c] = inputs
    let out: Shape
    if (op === 'Gemm') {
      check(
        (inputs.length === 2 || inputs.length === 3) && a.length === 2 && b.length === 2,
        'Gemm requires matrices.',
      )
      const [m, k] = Number(attrs.get('transA')?.i) ? [...a].reverse() : a
      const [k2, n] = Number(attrs.get('transB')?.i) ? [...b].reverse() : b
      out = [m, n]
      check(
        k === k2 && (!c || broadcast(out, c).join() === out.join()),
        'Incompatible Gemm dimensions.',
      )
      macs += m * k * n
    } else if (op === 'MatMul') {
      check(inputs.length === 2 && a.length && b.length, 'MatMul requires two inputs.')
      const aa = a.length === 1 ? [1, ...a] : a,
        bb = b.length === 1 ? [...b, 1] : b
      const batch = broadcast(aa.slice(0, -2), bb.slice(0, -2))
      const m = aa.at(-2)!,
        k = aa.at(-1)!,
        n = bb.at(-1)!
      check(k === bb.at(-2), 'Incompatible MatMul dimensions.')
      out = [...batch, ...(a.length === 1 ? [] : [m]), ...(b.length === 1 ? [] : [n])]
      macs += product(batch) * m * k * n
    } else if (op === 'Add') {
      check(inputs.length === 2, 'Add requires two inputs.')
      out = broadcast(a, b)
    } else {
      check(inputs.length === 1, op + ' requires one input.')
      out = a
    }
    elements += product(out)
    check(
      macs <= MAX_MACS && elements <= 262144,
      'The graph exceeds the per-decision compute budget.',
    )
    const name = node.output?.[0]
    check(
      name && node.output?.length === 1 && !shapes.has(name),
      'Each node needs one unique output.',
    )
    shapes.set(name, out)
    const dynamicInputs = (node.input ?? []).filter((input) => !constants.has(input))
    if (
      dynamicInputs.length !== 1 ||
      dynamicInputs[0] !== previous ||
      out.length !== 2 ||
      out[0] !== 1
    )
      sequential = false
    if (op === 'Gemm' || op === 'MatMul') widths.push(out.at(-1)!)
    else if (out.at(-1) !== widths.at(-1)) sequential = false
    operations.push({ op, inputs: node.input ?? [], output: name, shape: out })
    previous = name
  }
  check(
    shapes.get('action_scores')?.join() === '1,' + outputSize,
    'The graph must produce action_scores[1, ' + outputSize + '].',
  )
  return {
    inputSize,
    outputSize,
    params,
    macs,
    nodes: nodes.length,
    architecture: {
      widths: sequential && previous === 'action_scores' ? widths : null,
      operations,
    },
  }
}
