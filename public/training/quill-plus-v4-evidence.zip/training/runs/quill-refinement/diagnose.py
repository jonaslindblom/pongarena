"""Non-submittable diagnostic oracles: isolate approximation costs, no fitting."""
import sys,json
from pathlib import Path
import numpy as np,torch
sys.path.insert(0,str(Path('training/scripts').resolve()))
from policy import load_builtin,actions
from pace_study import CONFIGS,run_pair,make_policy,decode,tables
P=Path('training/runs/quill-refinement');torch.set_num_threads(1)
rules=CONFIGS['pace13-v9-scaled'];tab=tables(rules)
quill=load_builtin('quill-nano-v4')
def exact_forecast(obs):
 vx,own,other,t,h=decode(obs)
 target=(83/78)*h-(5/78)*np.where(other>=80,4,156)
 target=np.where(vx<0,target,80+np.where(other>=80,1,-1)*80*19/312)
 error=target-own
 return np.argmax(np.stack([-error,np.full(len(obs),1.1),error],1),1)
def exact_recovery(obs):
 vx,own,other,t,h=decode(obs)
 result=actions(quill,obs)
 target=tab['mid'][np.minimum(13,np.abs(vx)),h]
 error=target-own
 recovery=np.argmax(np.stack([-error,np.full(len(obs),1.1),error],1),1)
 return np.where(vx<0,result,recovery)
seeds=json.loads((P/'development-seeds.json').read_text())[:32]
result={}
for name,actor in [('quill',quill),('exact-forecast',exact_forecast),('exact-recovery',exact_recovery)]:
 result[name]={}
 for opponent in ['pacer-v4','prism-small-v4','attack','defend','quill-nano-v4']:
  rival=make_policy(rules,opponent) if opponent in ['attack','defend'] else load_builtin(opponent)
  r=run_pair(rules,actor,rival,seeds)
  result[name][opponent]=r
  s=r['summary'];print(name,opponent,[s[k] for k in ['wins','losses','draws']],flush=True)
(P/'diagnostics.json').write_text(json.dumps(result))
