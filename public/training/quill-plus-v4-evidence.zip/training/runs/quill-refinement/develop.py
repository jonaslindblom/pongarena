"""Named mathematical hypotheses, fixed by hand. No fitting or parameter search."""
import sys,json
from pathlib import Path
import numpy as np, torch, onnx
from torch import nn
from onnx import helper,numpy_helper
sys.path.insert(0,str(Path('training/scripts').resolve()))
from quill_dense_v4 import weights
from pace_study import CONFIGS,run_pair,make_policy
from policy import load_builtin
P=Path('training/runs/quill-refinement');torch.set_num_threads(1)

def center(arrays, C=19/312):
    # Make the two opponent ramps cancel on departure. Incoming aim unchanged.
    (w1,b1),(w2,b2),(w3,b3),(w4,b4)=arrays
    w2[1,10]=-4*C
    w2[3,10]=4
    w3[0,2]+=C
    b4[0]+=C;b4[2]-=C
    return arrays

def square(arrays, vertical_scale, spacing):
    # Symmetric square interpolation is exact at distance zero. Even integer
    # vertical velocities have matching interpolation errors in the two terms.
    (w1,b1),(w2,b2),(w3,b3),(w4,b4)=arrays
    knots=np.array([-1.5,-.5,.5,1.5])*spacing
    C=6*180/(13*80)/(4*vertical_scale)
    for j,sign in enumerate([1,-1]):
        for i,k in enumerate(knots):
            w1[4*j+i,3]=sign*vertical_scale;b1[4*j+i]=11/12-k
    w1[8,3]=6*(8/13)/80-4*spacing*2*vertical_scale*C
    w2[0,:4]=2*spacing*C;w2[0,4:8]=-w2[0,:4]
    return arrays

def extend_tail(arrays):
    # The last square segment begins at 4/3, but legal u reaches 17/6.
    # Minimax secant extension on that fixed interval: h=2L(sqrt(2)-1).
    # This changes no near-contact feature; there is no fitted coefficient.
    (w1,b1),(w2,b2),(w3,b3),(w4,b4)=arrays
    left=4/3;span=17/6-left
    endpoint=left+2*span*(np.sqrt(2)-1)
    slope=left+endpoint
    C=6*180/(13*80)/(4*2/3)
    w2[0,3]=(slope-2)*C;w2[0,7]=-w2[0,3]
    return arrays

def safe_aim(arrays):
    # Approximate Prism's connected safe-contact family. At the walls the
    # desired centers are 15.5 and 144.5, both physically reachable.
    (w1,b1),(w2,b2),(w3,b3),(w4,b4)=arrays
    C=-11.5/80
    w1[11]=0;w1[11,1]=40;w1[11,3]=40*6/80;b1[11]=1
    w2[1,11]=-C
    w3[0]=[1,-1,-4,-C]
    w4[0]=[-1,2,-2];w4[2]=[1,-2,2]
    b4[0]=6+C;b4[2]=-6-C
    return arrays

def speed_recovery(arrays):
    # Opponent-dependent recovery bias decreases linearly with horizontal
    # speed and vanishes at cap 13, where reply coverage is tightest.
    (w1,b1),(w2,b2),(w3,b3),(w4,b4)=arrays
    k=12/13;C=19/312
    w2[1,10]=-k*C/2;w2[3,10]=k
    return arrays

def safe_gradient(arrays):
    arrays=safe_aim(arrays)
    (w1,b1),(w2,b2),(w3,b3),(w4,b4)=arrays
    # Join Prism's 13.5-unit central contact offset to its 11.5-unit wall
    # offset with one straight line. Wall targets stay exactly 15.5/144.5.
    A=39/38;C=-13.5/80
    w2[1,11]=-C;w3[0]=[A,-1,-4*A,-C]
    w4[0]=[-1,2*A,-2*A];w4[2]=[1,-2*A,2*A]
    b4[0]=6+C;b4[2]=-6-C
    return arrays

def make(arrays):
    layers=[]
    for i,(w,b) in enumerate(arrays):
        layer=nn.Linear(w.shape[1],len(b))
        with torch.no_grad():
            layer.weight.copy_(torch.from_numpy(w));layer.bias.copy_(torch.from_numpy(b))
        layers.append(layer)
        if i<3:layers.append(nn.ReLU())
    actor=nn.Sequential(*layers).eval()
    assert sum(p.numel() for p in actor.parameters())==163
    return actor

def export(arrays,path):
    if path.exists(): raise FileExistsError(path)
    nodes=[];tensors=[];previous='observation'
    for i,(w,b) in enumerate(arrays):
        out='action_scores' if i==len(arrays)-1 else f'linear{i}'
        tensors += [numpy_helper.from_array(w,f'w{i}'),numpy_helper.from_array(b,f'b{i}')]
        nodes.append(helper.make_node('Gemm',[previous,f'w{i}',f'b{i}'],[out],transB=1));previous=out
        if i<len(arrays)-1:
            previous=f'hidden{i}';nodes.append(helper.make_node('Relu',[out],[previous]))
    m=helper.make_model(helper.make_graph(nodes,'Handwritten Quill refinement',[helper.make_tensor_value_info('observation',1,[1,6])],[helper.make_tensor_value_info('action_scores',1,[1,3])],tensors),opset_imports=[helper.make_opsetid('',18)],ir_version=10)
    helper.set_model_props(m,dict(rules='pong-v4',method='Explicit manual formula hypothesis; no training or fitting'))
    onnx.checker.check_model(m);onnx.save(m,path)

models={'baseline':weights(), 'center':center(weights()),
        'even-flight':square(weights(),1,2/3),
        'even-center':center(square(weights(),1,2/3)),
        'near-flight':square(weights(),2/3,4/9),
        'safe-aim':safe_aim(weights()),
        'safe-center':center(safe_aim(weights()),C=-11.5/80),
        'extended-tail':extend_tail(weights()),
        'extended-center':center(extend_tail(weights())),
        'speed-recovery':speed_recovery(extend_tail(weights())),
        'safe-gradient':safe_gradient(extend_tail(weights()))}
if __name__=='__main__':
    seeds=json.loads((P/'development-seeds.json').read_text())
    for name in sys.argv[1:] or models:
        arrays=models[name];actor=make(arrays);export(arrays,P/(name+'.onnx'))
        result={}
        for opponent in ['quill-nano-v4','pacer-v4','robust-strong-v4','prism-small-v4','plain-nano-v4','attack','defend']:
            rival=make_policy(CONFIGS['pace13-v9-scaled'],opponent) if opponent in ['attack','defend'] else load_builtin(opponent)
            r=run_pair(CONFIGS['pace13-v9-scaled'],actor,rival,seeds);result[opponent]=r
            s=r['summary'];print(name,opponent,[s[k] for k in ['wins','losses','draws']],flush=True)
        (P/(name+'-development.json')).write_text(json.dumps(result))
