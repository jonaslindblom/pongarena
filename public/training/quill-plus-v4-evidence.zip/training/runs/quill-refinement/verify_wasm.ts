import assert from 'node:assert/strict'
import { readFileSync, writeFileSync } from 'node:fs'
import * as ort from 'onnxruntime-web/wasm'
import { advance, choice, endedMatch, LoopDetector, observation, serve, type Pair, type Scores } from '../../../src/game.ts'
const directory = 'training/runs/quill-refinement/'
ort.env.wasm.numThreads = 1
const sessions = new Map<string, ort.InferenceSession>()
for (const name of ['quill-plus-v4', 'pacer-v4', 'robust-strong-v4']) sessions.set(name,
  await ort.InferenceSession.create(readFileSync(`public/models/${name}.onnx`), { executionProviders: ['wasm'] }))
let maximumScoreError = 0, decisions = 0, frames = 0
async function check(name: string, obs: Float32Array, expected: Scores) {
  const output = await sessions.get(name)!.run({ observation: new ort.Tensor('float32', obs, [1, 6]) })
  const scores = Array.from(output.action_scores.data as Float32Array) as Scores
  const error = Math.max(...scores.map((score, i) => Math.abs(score - expected[i])))
  maximumScoreError = Math.max(maximumScoreError, error)
  assert.ok(error < 2e-5, `Native/WASM scores disagree: ${name}, ${error}`)
  assert.equal(choice(scores), choice(expected), 'Runtime differences must never change a recorded action')
  decisions++
  return scores
}
const probes = JSON.parse(readFileSync(directory + 'native-probes.json', 'utf8'))
for (const probe of probes) await check('quill-plus-v4', new Float32Array(probe.observation), probe.scores)
const matches = JSON.parse(readFileSync(directory + 'native-replays.json', 'utf8'))
for (const match of matches) {
  let frame = serve(match.seed)
  const loops = new LoopDetector()
  for (const step of match.steps) {
    if (step.scores === null) frame = serve(match.seed, frame)
    else {
      const scores = await Promise.all(([0, 1] as const).map(side => check(match.models[side], observation(frame, side), step.scores[side]))) as Pair<Scores>
      frame = advance(frame, scores, loops)
    }
    const { scores: actualScores, ...actual } = frame
    const { scores: expectedScores, ...expected } = step.state
    assert.deepEqual(JSON.parse(JSON.stringify(actual)), expected, 'WASM play must reproduce native physics, scores and termination')
    frames++
  }
  assert.ok(endedMatch(frame))
}
for (const session of sessions.values()) await session.release()
const result = { probes: probes.length, matches: matches.length, frames, decisions, maximumScoreError,
  actionMismatches: 0, stateMismatches: 0, reproduction: 'byte-identical', runtime: 'ONNX Runtime Web WASM, Node.js' }
writeFileSync(directory + 'verification.json', JSON.stringify(result, null, 2) + '\n')
console.log(result)
