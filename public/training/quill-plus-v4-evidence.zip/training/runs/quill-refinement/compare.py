"""Compare frozen models on common seeds, clustering all opponents per seed."""
import json
from pathlib import Path
import numpy as np
P=Path('training/runs/quill-refinement')
a=json.loads((P/'original-heldout.json').read_text());b=json.loads((P/'plus-heldout.json').read_text())
assert a['seeds']==b['seeds']
field=list(a['opponents']);assert len(field)==10
scores=[]
rows={}
for name in field:
 old=a['opponents'][name]['summary'];new=b['opponents'][name]['summary']
 difference=np.array([n['paired_point_margin']-o['paired_point_margin'] for o,n in zip(old['per_seed'],new['per_seed'])])/20
 scores.append(difference)
 rows[name]=dict(original={k:old[k] for k in ['wins','losses','draws','score_rate']},plus={k:new[k] for k in ['wins','losses','draws','score_rate']},score_gain=float(difference.mean()))
 print(name,'old',[old[k] for k in ['wins','losses','draws']],'new',[new[k] for k in ['wins','losses','draws']],f"gain {difference.mean()*100:+.2f} pp")
per_seed=np.mean(scores,axis=0)
bootstrap=np.random.default_rng(16320261107).integers(0,len(per_seed),(20000,len(per_seed)))
interval=np.quantile(per_seed[bootstrap].mean(1),[.025,.975])
old_mean=np.mean([a['opponents'][n]['summary']['score_rate'] for n in field]);new_mean=np.mean([b['opponents'][n]['summary']['score_rate'] for n in field])
head=b['opponents']['quill-nano-v4']['summary']
summary=dict(field=field,seeds=a['seeds'],rallies_per_opponent=1280,original_score_rate=float(old_mean),plus_score_rate=float(new_mean),score_gain=float(per_seed.mean()),score_gain_ci95=interval.tolist(),promotion_passed=bool(interval[0]>0),matchups=rows,direct={k:head[k] for k in ['wins','losses','draws','score_rate','point_margin_ci95','paired_match_wins','paired_match_losses','paired_match_draws']},bootstrap='20,000 resamples of whole seeds, jointly retaining both models, all ten opponents, sides and rallies; draw counts as half a point')
(P/'comparison.json').write_text(json.dumps(summary,indent=2)+'\n')
print('MEAN',old_mean,new_mean,'GAIN CI',interval,'DIRECT',summary['direct'])
